source ./set_demo_env
uv run pytest tests/it
