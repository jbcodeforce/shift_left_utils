insert into src_c360_users_ut
(
	`user_id`,
	`user_name`,
	`user_email`,
	`group_id`,
	`tenant_id`,
	`created_date`,
	`is_active`,
	`updated_at`
)
values
('user_id_1', 'user_name_1', 'user_email_1', 'group_id_1', 'tenant_id_1', 'created_date_1', false, TIMESTAMP '2021-01-01 00:00:00'),
('user_id_2', 'user_name_2', 'user_email_2', 'group_id_2', 'tenant_id_2', 'created_date_2', true, TIMESTAMP '2021-01-01 00:00:00'),
('user_id_3', 'user_name_3', 'user_email_3', 'group_id_3', 'tenant_id_3', 'created_date_3', false, TIMESTAMP '2021-01-01 00:00:00');