-- Integration test synthetic data for raw_users
-- Generated on: 2025-09-23T15:55:53.933146+00:00
-- Unique test ID: 73c3de37-24cd-4491-8289-d6c01fe1200c
INSERT INTO raw_users_it (user_id, user_name, user_email, group_id, tenant_id, created_date, is_active
) VALUES (
    -- Add appropriate test values here
'user_id_1', 'user_name_1', 'user_email_1', 'group_id_1', 'tenant_id_1', 'created_date_1', false
);
