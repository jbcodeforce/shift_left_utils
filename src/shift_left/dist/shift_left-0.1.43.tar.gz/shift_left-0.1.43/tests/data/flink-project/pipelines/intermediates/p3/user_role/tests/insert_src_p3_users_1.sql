insert into src_p3_users_ut
(user_id, tenant_id, role_id, status)
values
('user_id_1', 'tenant_id_1', 'role_id_1', 'status_1'),
('user_id_2', 'tenant_id_2', 'role_id_2', 'status_2'),
('user_id_3', 'tenant_id_3', 'role_id_3', 'status_3'),
('user_id_4', 'tenant_id_4', 'role_id_4', 'status_4'),
('user_id_5', 'tenant_id_5', 'role_id_5', 'status_5');

