export SL_LLM_BASE_URL=http://localhost:11434/v1
export SL_LLM_MODEL=qwen3:30b
export SL_LLM_API_KEY=ollama_test_key