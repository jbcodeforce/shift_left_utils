insert into c_ut
(`default_key`, `c_value`, `z_value`, `b_value`)
values
('default_key_1', 'c_value_1', 'z_value_1', 'b_value_1'),
('default_key_2', 'c_value_2', 'z_value_2', 'b_value_2'),
('default_key_3', 'c_value_3', 'z_value_3', 'b_value_3');

