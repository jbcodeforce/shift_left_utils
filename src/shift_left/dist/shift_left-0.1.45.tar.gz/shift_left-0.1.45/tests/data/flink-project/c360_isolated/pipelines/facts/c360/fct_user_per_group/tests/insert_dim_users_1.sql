insert into dim_users_ut
(`user_id`, `user_name`, `user_email`, `group_id`, `group_name`, `group_type`, `created_date`, `is_active`)
values
('user_id_1', 'user_name_1', 'user_email_1', 'group_id_1', 'group_name_1', 'group_type_1', 'created_date_1', false),
('user_id_2', 'user_name_2', 'user_email_2', 'group_id_2', 'group_name_2', 'group_type_2', 'created_date_2', true),
('user_id_3', 'user_name_3', 'user_email_3', 'group_id_3', 'group_name_3', 'group_type_3', 'created_date_3', false);

