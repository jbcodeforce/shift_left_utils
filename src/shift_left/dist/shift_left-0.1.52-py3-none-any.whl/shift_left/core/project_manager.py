"""
Copyright 2024-2025 Confluent, Inc.

Service to manage project structure.
"""
import datetime
import glob
import os
from pathlib import Path
import re
import hashlib
import subprocess
import shutil
import importlib.resources
import yaml
from datetime import timezone
from typing import Tuple, List, Any, Union, Literal
from pydantic import BaseModel, Field
from shift_left.core.models.flink_test_model import SLTestDefinition
from shift_left.core.test_mgr import TEST_DEFINITION_FILE_NAME
from shift_left.core.table_mgr import get_or_build_inventory
from shift_left.core.utils.ccloud_client import ConfluentCloudClient
from shift_left.core.utils.app_config import get_config, logger, shift_left_dir
from shift_left.core.pipeline_mgr import FlinkTablePipelineDefinition
from shift_left.core.utils.file_search import (
    PIPELINE_JSON_FILE_NAME,
    PIPELINE_FOLDER_NAME,
    get_table_ref_from_inventory,
    read_pipeline_definition_from_file,
    from_pipeline_to_absolute,
    create_folder_if_not_exist,
)
from shift_left.core.utils.sql_parser import SQLparser
from shift_left.core.utils.ddl_schema_diff import (
    BaselineMode,
    SchemaDiff,
    diff_column_metadata,
    ensure_git_branch,
    get_git_baseline_content,
    get_git_repo_root,
    merge_added_columns_into_ddl,
    merge_added_columns_into_insert_sql,
    merge_added_columns_into_validation_sql,
)
from jinja2 import Environment, PackageLoader
import shift_left.core.statement_mgr as statement_mgr
from shift_left.core.models.flink_statement_model import Statement
from shift_left.core.utils.table_worker import ReplaceVersionInSqlContent
DATA_PRODUCT_PROJECT_TYPE="data_product"
KIMBALL_PROJECT_TYPE="kimball"
TMPL_FOLDER="templates"


class ModifiedFileInfo(BaseModel):
    table_name: str = Field(description="Extracted table name")
    file_modified_url: str = Field(description="File path/URL of the modified file")
    same_sql_content: bool = Field(description="Whether the SQL is the same as the running statement")
    running: bool = Field(description="Whether the statement is running")
    new_table_name: str = Field(description="New table name after versioning")
    schema_diff: SchemaDiff | None = Field(
        default=None,
        description="Top-level DDL column changes vs git baseline; set for production DDL files only",
    )

    def __hash__(self) -> int:
        return hash(self.table_name)
    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, ModifiedFileInfo):
            return NotImplemented
        return self.table_name == other.table_name and self.file_modified_url == other.file_modified_url


class ModifiedFilesResult(BaseModel):
    """Result of list_modified_files operation"""
    description: str = Field(description="Summary information about the operation")
    file_list: set[ModifiedFileInfo] = Field(description="Set of modified files with extracted table names")


class ImpactedTablesByModificationsResult(BaseModel):
    """Tables and DDL paths impacted by production DDL modifications."""
    ddl_modified_tables: list[str] = Field(
        description="Table names whose production DDL files were modified"
    )
    impacted_tables: list[str] = Field(
        description="Downstream tables (recursive children of DDL-modified tables)"
    )
    production_ddl_paths: list[str] = Field(
        description="Paths to production DDL files relative to PIPELINES for impacted downstream tables"
    )
    unit_test_ddl_paths: list[str] = Field(
        description="Paths to unit-test foundation DDL files relative to PIPELINES"
    )


class MergeUtArtifactsResult(BaseModel):
    """Paths of unit-test artifacts updated by merge_unit_test_ddl_columns."""
    ddl_paths: list[str] = Field(default_factory=list)
    insert_paths: list[str] = Field(default_factory=list)
    validate_paths: list[str] = Field(default_factory=list)

# ------- Public APIS ----------

def build_project_structure(project_name: str,
                            project_path: str,
                            project_type: str):
    logger.info(f"build_project_structure({project_name}, {project_path}, {project_type}")
    project_folder=os.path.join(project_path, project_name)
    create_folder_if_not_exist(project_folder)
    create_folder_if_not_exist(os.path.join(project_folder, "pipelines"))
    create_folder_if_not_exist(os.path.join(project_folder, "docs"))
    if project_type == DATA_PRODUCT_PROJECT_TYPE:
        _define_dp_structure(os.path.join(project_folder, "pipelines"))
    else:
        _define_kimball_structure(os.path.join(project_folder, "pipelines"))
    _initialize_git_repo(project_folder)
    _add_important_files(project_folder)
    _create_terraform_skeleton(project_folder)




def get_topic_list(file_name: str) -> list[dict]:
    """
    Get the list of topics from the Confluent Cloud and save it to a file.
    """
    ccloud = ConfluentCloudClient(get_config())
    topics = ccloud.list_topics()
    logger.info(f"get_topic_list: {topics}")
    if topics and topics.get('data'):
        with open(file_name, "w") as f:
            for topic in topics["data"]:
                f.write(f"{topic['cluster_id']},{topic['topic_name']},{topic['partitions_count']}\n")
        return topics["data"]
    else:
        return []


def report_table_cross_products(project_path: str):
    """
    Return the lit of table names for tables that are referenced in other products.
    """
    if not project_path:
        project_path = os.getenv("PIPELINES")
    inventory = get_or_build_inventory(project_path, project_path, False)
    risky_tables = []
    for table_name, table_ref in inventory.items():
        try:
            table_hierarchy: FlinkTablePipelineDefinition= read_pipeline_definition_from_file(table_ref['table_folder_name'] + "/" + PIPELINE_JSON_FILE_NAME)
            if table_hierarchy:
                for child in table_hierarchy.children:
                    if child.product_name != table_ref['product_name']:
                        risky_tables.append(table_name)
                        break
        except Exception as e:
            logger.error(f"Error in reporting table cross products: {e}")
            continue
    return risky_tables


def list_tables_with_one_child(project_path: str):
    """
    Return the list of table names for tables that have exactly one child table.

    Args:
        project_path: Path to the pipeline folder. If not provided, uses $PIPELINES environment variable.

    Returns:
        List of table names that have exactly one child
    """
    if not project_path:
        project_path = os.getenv("PIPELINES")
    inventory = get_or_build_inventory(project_path, project_path, False)
    tables_with_one_child = []
    for table_name, table_ref in inventory.items():
        table_hierarchy: FlinkTablePipelineDefinition = read_pipeline_definition_from_file(
            table_ref['table_folder_name'] + "/" + PIPELINE_JSON_FILE_NAME
        )
        if table_hierarchy and table_hierarchy.children and len(table_hierarchy.children) <= 1:
            tables_with_one_child.append(table_name)
    return tables_with_one_child


def impacted_tables_by_modifications(
    modified_files: Union[ModifiedFilesResult, dict],
    project_path: str | None = None,
) -> ImpactedTablesByModificationsResult:
    """
    From modified file metadata, find downstream tables and DDL files affected by production DDL changes.

    Filters to production DDL under sql-scripts, walks pipeline children recursively, and collects
    matching unit-test foundation DDL paths from test_definitions.yaml files.
    """
    result = _normalize_modified_files_result(modified_files)
    pipelines_path = project_path or os.getenv("PIPELINES")
    if not pipelines_path:
        raise ValueError("project_path must be provided or PIPELINES environment variable must be set")

    ddl_modified_tables = _extract_ddl_modified_tables(result.file_list)
    inventory = get_or_build_inventory(pipelines_path, pipelines_path, False)
    tables = _collect_descendant_tables(ddl_modified_tables, inventory)
    production_ddl_paths = _resolve_production_ddl_paths(tables, inventory, pipelines_path)
    impacted_names = set(ddl_modified_tables) | set(tables)
    unit_test_ddl_paths = _collect_unit_test_ddl_paths(
        pipelines_path, impacted_names, inventory
    )

    return ImpactedTablesByModificationsResult(
        ddl_modified_tables=sorted(ddl_modified_tables),
        impacted_tables=sorted(tables),
        production_ddl_paths=sorted(production_ddl_paths),
        unit_test_ddl_paths=sorted(unit_test_ddl_paths),
    )


def update_unit_test_ddl_for_foundation_tables(
    impacted: Union[ImpactedTablesByModificationsResult, dict],
    project_path: str | None = None,
) -> List[str]:
    """
    Update unit-test foundation DDL files from production DDL for ddl_modified_tables only.

    Scans test_definitions.yaml under PIPELINES, and for each foundation whose production
    table had a DDL modification, rewrites the foundation ddl_for_test file using the current
    production CREATE TABLE (with the configured unit-test table name postfix).

    Args:
        impacted: Output from impacted_tables_by_modifications or impacted_tables.json content.
        project_path: Pipeline root ($PIPELINES). Required if PIPELINES is not set.

    Returns:
        Paths (relative to PIPELINES) of unit-test DDL files that were updated.
    """
    if isinstance(impacted, dict):
        impacted = ImpactedTablesByModificationsResult.model_validate(impacted)
    pipelines_path = project_path or os.getenv("PIPELINES")
    if not pipelines_path:
        raise ValueError("project_path must be provided or PIPELINES environment variable must be set")
    if not impacted.ddl_modified_tables:
        return []

    inventory = get_or_build_inventory(pipelines_path, pipelines_path, False)
    post_fix = get_config().get("app", {}).get("post_fix_unit_test", "_ut")
    return _sync_foundation_ut_ddl_from_production(
        impacted.ddl_modified_tables, pipelines_path, inventory, post_fix
    )


def merge_unit_test_ddl_columns(
    modified_files: Union[ModifiedFilesResult, dict],
    impacted: Union[ImpactedTablesByModificationsResult, dict],
    git_branch: str,
    project_path: str | None = None,
    repo_root: str | None = None,
) -> MergeUtArtifactsResult:
    """
    Merge added columns from production schema_diff into unit-test DDL, insert, and validation files.

    Creates or checks out git_branch (fails on dirty work tree). Does not auto-commit.
    """
    modified = _normalize_modified_files_result(modified_files)
    if isinstance(impacted, dict):
        impacted = ImpactedTablesByModificationsResult.model_validate(impacted)

    pipelines_path = project_path or os.getenv("PIPELINES")
    if not pipelines_path:
        raise ValueError("project_path must be provided or PIPELINES environment variable must be set")

    schema_diff_by_table = _build_schema_diff_by_table(modified, impacted.ddl_modified_tables)
    if not schema_diff_by_table:
        raise ValueError(
            "No schema_diff.added entries found for ddl_modified_tables. "
            "Re-run list-modified-files with --baseline."
        )

    root = repo_root or get_git_repo_root()
    ensure_git_branch(root, git_branch)

    inventory = get_or_build_inventory(pipelines_path, pipelines_path, False)
    parser = SQLparser()
    result = MergeUtArtifactsResult()
    seen_ddl: set[str] = set()
    seen_insert: set[str] = set()
    seen_validate: set[str] = set()

    pattern = os.path.join(pipelines_path, "**", "tests", TEST_DEFINITION_FILE_NAME)
    for definition_path in glob.glob(pattern, recursive=True):
        tests_folder = os.path.dirname(definition_path)
        table_folder = os.path.dirname(tests_folder)
        try:
            with open(definition_path, "r") as f:
                test_definition = SLTestDefinition.model_validate(yaml.safe_load(f))
        except Exception as e:
            logger.debug(f"Skipping {definition_path}: {e}")
            continue

        foundation_tables_processed: set[str] = set()
        for foundation in test_definition.foundations:
            inventory_table = _resolve_foundation_inventory_table(
                foundation.table_name, inventory
            )
            if not inventory_table or inventory_table not in schema_diff_by_table:
                continue
            if inventory_table in foundation_tables_processed:
                continue
            foundation_tables_processed.add(inventory_table)

            schema_diff = schema_diff_by_table[inventory_table]
            prod_meta, raw_defs = _production_column_context(inventory_table, inventory, parser)
            added_defs = {
                col: raw_defs[col]
                for col in schema_diff.added
                if col in raw_defs
            }
            if not added_defs:
                logger.warning(
                    f"No raw column definitions for added columns on {inventory_table}; skipping foundation DDL"
                )
                continue

            ut_ddl_path = os.path.normpath(
                os.path.join(table_folder, foundation.ddl_for_test.lstrip("./"))
            )
            if os.path.exists(ut_ddl_path):
                with open(ut_ddl_path, "r") as f:
                    ut_ddl = f.read()
                updated_ddl, added = merge_added_columns_into_ddl(ut_ddl, added_defs, parser)
                if added:
                    with open(ut_ddl_path, "w") as f:
                        f.write(updated_ddl)
                    rel = _path_relative_to_pipelines(ut_ddl_path, pipelines_path)
                    if rel not in seen_ddl:
                        seen_ddl.add(rel)
                        result.ddl_paths.append(rel)
                    logger.info(f"Merged columns {added} into UT DDL {rel}")

            for test_case in test_definition.test_suite:
                for test_input in test_case.inputs:
                    if test_input.table_name != foundation.table_name:
                        continue
                    if test_input.file_type != "sql":
                        continue
                    insert_path = os.path.normpath(
                        os.path.join(table_folder, test_input.file_name.lstrip("./"))
                    )
                    if not os.path.exists(insert_path):
                        logger.debug(f"Insert file not found: {insert_path}")
                        continue
                    with open(insert_path, "r") as f:
                        insert_sql = f.read()
                    try:
                        updated_insert, added = merge_added_columns_into_insert_sql(
                            insert_sql, schema_diff.added, prod_meta
                        )
                    except ValueError as e:
                        logger.warning(f"Skipping insert merge for {insert_path}: {e}")
                        continue
                    if added:
                        with open(insert_path, "w") as f:
                            f.write(updated_insert)
                        rel = _path_relative_to_pipelines(insert_path, pipelines_path)
                        if rel not in seen_insert:
                            seen_insert.add(rel)
                            result.insert_paths.append(rel)
                        logger.info(f"Merged columns {added} into insert {rel}")

        for test_case in test_definition.test_suite:
            for test_output in test_case.outputs:
                if test_output.file_type != "sql":
                    continue
                inventory_table = _resolve_foundation_inventory_table(
                    test_output.table_name, inventory
                )
                if not inventory_table or inventory_table not in schema_diff_by_table:
                    continue
                schema_diff = schema_diff_by_table[inventory_table]
                prod_meta, _ = _production_column_context(inventory_table, inventory, parser)
                validate_path = os.path.normpath(
                    os.path.join(table_folder, test_output.file_name.lstrip("./"))
                )
                if not os.path.exists(validate_path):
                    logger.debug(f"Validation file not found: {validate_path}")
                    continue
                with open(validate_path, "r") as f:
                    validate_sql = f.read()
                try:
                    updated_validate, added = merge_added_columns_into_validation_sql(
                        validate_sql, schema_diff.added, prod_meta
                    )
                except ValueError as e:
                    logger.warning(f"Skipping validation merge for {validate_path}: {e}")
                    continue
                if added:
                    with open(validate_path, "w") as f:
                        f.write(updated_validate)
                    rel = _path_relative_to_pipelines(validate_path, pipelines_path)
                    if rel not in seen_validate:
                        seen_validate.add(rel)
                        result.validate_paths.append(rel)
                    logger.info(f"Merged columns {added} into validation {rel}")

    return result


def list_modified_files(project_path: str,
                        branch_name: str,
                        since: str,
                        file_filter: str,
                        output_file: str,
                        baseline_mode: BaselineMode = "since") -> ModifiedFilesResult:
    """List modified files and return structured result.

    Args:
        project_path: Path to the project directory
        branch_name: Git branch name to check
        since: Date filter for git log (YYYY-MM-DD format)
        file_filter: File extension filter (e.g., '.sql')
        output_file: Optional output file path (for backward compatibility)
        baseline_mode: DDL baseline for schema diff: 'since' or 'branch'

    Returns:
        ModifiedFilesResult: Structured result with description and file list

    Raises:
        subprocess.CalledProcessError: If git commands fail
        Exception: For other errors
    """
    try:
        # Change to project directory
        original_cwd = os.getcwd()
        if project_path and project_path != ".":
            os.chdir(project_path)

        # Get the current branch name
        current_branch_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            check=True
        )
        current_branch = current_branch_result.stdout.strip()
        logger.info(f"Current branch: {current_branch}")
        if current_branch != branch_name:
            print(f"Current branch is not the same as the specified branch {branch_name}, I will automaticall checkout to {branch_name}")
            subprocess.run(
                ["git", "checkout", f"{branch_name}"],
                capture_output=True,
                text=True,
                check=True
            )
        if not since:
            # If no date_filter is provided, set it to yesterday's date in YYYY-MM-DD format
            yesterday = (datetime.datetime.now(timezone.utc) - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
            since = yesterday
        # Get list of modified files compared to the specified branch
        git_diff_result = subprocess.run(
            ["git", "log", "--name-only", f"--since={since}", '--pretty=format:'],
            capture_output=True,
            text=True,
            check=True
        )

        all_modified_files = git_diff_result.stdout.strip().split('\n')
        all_modified_files = [f for f in all_modified_files if f.strip()]  # Remove empty strings
        # Filter for specific file types (default: SQL files)
        # absolute path -> git repo-relative path (for git show baseline)
        filtered_files: dict[str, str] = {}
        for file_path in all_modified_files:
            lowered_file_path = file_path.lower()
            if file_filter in lowered_file_path and PIPELINE_FOLDER_NAME in lowered_file_path:
                logger.info(f"Checking file: {file_path}")
                # Exclude files that have a parent folder named 'tests'
                # (i.e., a path segment '/tests/' or startswith 'tests/')
                normalized_path = os.path.normpath(file_path)
                path_parts = normalized_path.split(os.sep)
                # Check if any parent directory is 'tests'
                if "tests" in path_parts[-2]:
                    logger.info(f"Skipping file: {file_path} because it has a parent folder named 'tests'")
                    continue
                try:
                    pipeline_idx = path_parts.index(PIPELINE_FOLDER_NAME)
                except ValueError:
                    logger.warning(f"File {file_path} is not under '{PIPELINE_FOLDER_NAME}', skipping")
                    continue
                pipeline_relative = os.path.join(*path_parts[pipeline_idx + 1:])
                if os.path.basename(os.path.normpath(project_path)) == PIPELINE_FOLDER_NAME:
                    absolute_file_path = os.path.join(project_path, pipeline_relative)
                else:
                    absolute_file_path = os.path.join(
                        project_path, PIPELINE_FOLDER_NAME, pipeline_relative
                    )
                if not os.path.exists(absolute_file_path):
                    logger.warning(f"File {absolute_file_path} does not currently exist, skipping")
                    continue
                git_repo_path = normalized_path.replace("\\", "/")
                filtered_files[absolute_file_path] = git_repo_path

        print(f"Found {len(all_modified_files)} total modified files")

        print(f"Found {len(filtered_files)} modified files matching filter '{file_filter}'")

        generated_on = datetime.datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        description = (
            f"Modified files in branch:'{current_branch}'\n"
            f"Filter applied: {file_filter}\n"
            f"Generated on: {generated_on}\n"
            f"Total files: {len(filtered_files)}"
        )
        logger.info(description)
        # Create file list with extracted table names
        file_list = set()
        parser = SQLparser()
        for absolute_file_path in sorted(filtered_files):
            git_repo_path = filtered_files[absolute_file_path]
            with open(absolute_file_path, 'r') as file:
                sql_content = file.read()
                schema_diff = None
                if "create table" in sql_content.lower() or "create or replace table" in sql_content.lower():
                    table_name = parser.extract_table_name_from_create_statement(sql_content)
                    same_sql, running = False, False
                    if _is_production_ddl_modification(absolute_file_path):
                        schema_diff = _compute_ddl_schema_diff(
                            parser, sql_content, git_repo_path, baseline_mode, since, branch_name
                        )
                else:
                    table_name = parser.extract_table_name_from_insert_into_statement(sql_content)
                    if table_name == "No-Table":
                        logger.warning(f"No table name found in file {sql_content}, skipping")
                        continue
                    same_sql, running = _assess_flink_statement_state(table_name, absolute_file_path, sql_content)
            file_list.add(ModifiedFileInfo(
                table_name=table_name,
                file_modified_url=absolute_file_path,
                same_sql_content=same_sql,
                running=running,
                new_table_name=table_name,
                schema_diff=schema_diff,
            ))

        # Create result object
        result = ModifiedFilesResult(
            description=description,
            file_list=file_list
        )

        # Backward compatibility: write to file if output_file is provided
        if output_file:
            output_path = Path(output_file)
            if not output_path.is_absolute():
                output_path = Path(original_cwd) / output_path

            with open(output_path, 'w') as f:
                f.write(result.model_dump_json(indent=2))

            print(f"\nFile list saved to: {output_path}")

        # Display results
        if filtered_files:
            logger.info(f"\nModified {file_filter} files:")
            for file_info in file_list:
                logger.info(f"  {file_info.table_name}: {file_info.file_modified_url}")
        else:
            logger.info(f"\nNo modified files found matching filter '{file_filter}'")
        return result

    except subprocess.CalledProcessError as e:
        print(f"❌ Git command failed: {e}")
        print(f"Error output: {e.stderr}")
        raise e
    except Exception as e:
        print(f"❌ Error: {e}")
        raise e
    finally:
        # Restore original working directory
        os.chdir(original_cwd)


def update_tables_version(to_process_tables: list[ModifiedFileInfo], default_version: str):
    """
    Update the table version within the DDL and DML SQL content for the given list of table names
    """
    inventory = get_or_build_inventory(os.getenv("PIPELINES"), os.getenv("PIPELINES"), False)
    processed_files = set[ModifiedFileInfo]()
    for file_info in to_process_tables:
        _update_version_in_current_ddl_dml(file_info, processed_files, default_version, inventory)
        _add_children_to_process_files(file_info, to_process_tables, inventory)
    return processed_files


def isolate_data_product(product_name: str, source_folder: str, target_folder: str):
    logger.info(f"isolate_data_product({product_name}, {source_folder}, {target_folder})")
    """
    isolate a data product table hierarchy for a given product name to be copied to a target folder.
    go to the facts and build a list of tables for this product name.
    add any children of the tables in the list of facts, recursively.
    build an integrated execution plan from the list of tables.
    move all the folder to the target folder.
    """
    inventory = get_or_build_inventory(source_folder, source_folder, False)
    tables = [table for table in inventory if inventory[table]['product_name'] == product_name]
    tables_to_process = {}
    visited = set()

    # Process each table and recursively find all its parents
    for table in tables:
        logger.info(f"Processing table {table} and finding all its dependencies")
        _find_all_parent_tables_recursive(table, inventory, visited, tables_to_process)

    logger.info(f"Found {len(tables_to_process)} total tables to process (including all dependencies)")

    # Copy all tables (original + all dependencies) to target folder

    for table, table_folder_name in tables_to_process.items():
        logger.info(f"Copying table: {table}, from {table_folder_name} to {target_folder}")

        # Keep the hierarchy of folder in the table_folder_name
        print(f"Copying table: {table}, from {table_folder_name} to {target_folder}")
        shutil.copytree(
            os.path.join(source_folder, '..', table_folder_name),
            os.path.join(target_folder, table_folder_name),
            dirs_exist_ok=True
        )
    with open(os.path.join(shift_left_dir, "tables_to_process.txt"), "w") as f:
        for table, table_folder_name in tables_to_process.items():
            f.write(f"{table},{table_folder_name}\n")


# ----------------------------------
# --- Private APIs ---
# ----------------------------------

def _normalize_modified_files_result(
    modified_files: Union[ModifiedFilesResult, dict],
) -> ModifiedFilesResult:
    if isinstance(modified_files, ModifiedFilesResult):
        return modified_files
    file_list = modified_files.get("file_list", [])
    entries = [
        ModifiedFileInfo.model_validate(item) if isinstance(item, dict) else item
        for item in file_list
    ]
    return ModifiedFilesResult(
        description=modified_files.get("description", ""),
        file_list=set(entries),
    )


def _build_schema_diff_by_table(
    modified_files: ModifiedFilesResult,
    ddl_modified_tables: list[str],
) -> dict[str, SchemaDiff]:
    allowed = set(ddl_modified_tables)
    by_table: dict[str, SchemaDiff] = {}
    for file_info in modified_files.file_list:
        if file_info.table_name not in allowed:
            continue
        if not file_info.schema_diff or not file_info.schema_diff.added:
            continue
        by_table[file_info.table_name] = file_info.schema_diff
    return by_table


def _production_column_context(
    inventory_table: str,
    inventory: dict,
    parser: SQLparser,
) -> tuple[dict[str, dict], dict[str, str]]:
    table_ref = inventory.get(inventory_table)
    if not table_ref or not table_ref.get("ddl_ref"):
        return {}, {}
    production_ddl_path = from_pipeline_to_absolute(table_ref["ddl_ref"])
    if not os.path.exists(production_ddl_path):
        return {}, {}
    with open(production_ddl_path, "r") as f:
        ddl_sql = f.read()
    return (
        parser.build_column_metadata_from_sql_content(ddl_sql),
        parser.extract_raw_column_definitions(ddl_sql),
    )


def _is_production_ddl_modification(file_modified_url: str) -> bool:
    normalized = os.path.normpath(file_modified_url)
    path_parts = normalized.split(os.sep)
    if len(path_parts) >= 2 and path_parts[-2] == "tests":
        return False
    if "/sql-scripts/" not in normalized.replace("\\", "/"):
        return False
    return os.path.basename(normalized).lower().startswith("ddl.")


def _compute_ddl_schema_diff(
    parser: SQLparser,
    current_sql: str,
    git_repo_path: str,
    baseline_mode: BaselineMode,
    since: str,
    branch_name: str,
) -> SchemaDiff | None:
    """Compare current DDL columns to the git baseline; None if current DDL is not parseable."""
    new_cols = parser.build_column_metadata_from_sql_content(current_sql)
    if not new_cols:
        logger.debug(f"No parseable CREATE TABLE in current DDL: {git_repo_path}")
        return None
    try:
        baseline_sql, baseline_ref = get_git_baseline_content(
            git_repo_path, baseline_mode, since, branch_name
        )
    except subprocess.CalledProcessError as e:
        logger.warning(f"Could not resolve git baseline for {git_repo_path}: {e}")
        return None
    if baseline_mode == "branch" and baseline_sql is None:
        logger.warning(f"No baseline DDL at branch {branch_name} for {git_repo_path}")
        return None
    old_cols = (
        parser.build_column_metadata_from_sql_content(baseline_sql)
        if baseline_sql
        else {}
    )
    return diff_column_metadata(old_cols, new_cols, baseline_ref)


def _extract_ddl_modified_tables(file_list: set[ModifiedFileInfo]) -> list[str]:
    tables: list[str] = []
    seen: set[str] = set()
    for file_info in file_list:
        if not _is_production_ddl_modification(file_info.file_modified_url):
            continue
        if file_info.table_name not in seen:
            seen.add(file_info.table_name)
            tables.append(file_info.table_name)
    return tables


def _collect_descendant_tables(
    ddl_modified_tables: list[str],
    inventory: dict,
) -> list[str]:
    descendants: set[str] = set()
    for table_name in ddl_modified_tables:
        _walk_pipeline_children(table_name, inventory, descendants, set())
    return sorted(descendants)


def _walk_pipeline_children(
    table_name: str,
    inventory: dict,
    descendants: set[str],
    visited: set[str],
) -> None:
    if table_name in visited:
        return
    visited.add(table_name)
    if table_name not in inventory:
        logger.warning(f"Table {table_name} not found in inventory while collecting descendants")
        return
    table_ref = inventory[table_name]
    pipeline_definition = read_pipeline_definition_from_file(
        table_ref["table_folder_name"] + "/" + PIPELINE_JSON_FILE_NAME
    )
    if not pipeline_definition or not pipeline_definition.children:
        return
    for child in pipeline_definition.children:
        descendants.add(child.table_name)
        _walk_pipeline_children(child.table_name, inventory, descendants, visited)


def _path_relative_to_pipelines(path: str, pipelines_path: str) -> str:
    """Return a path relative to the PIPELINES directory (no leading pipelines/ segment)."""
    pipelines_path = os.path.normpath(os.path.abspath(pipelines_path))
    pipeline_segment = os.path.basename(pipelines_path)

    normalized = path.replace("\\", "/")
    if not os.path.isabs(path):
        if normalized.startswith(f"{pipeline_segment}/"):
            return normalized[len(pipeline_segment) + 1 :]
        return normalized

    rel = os.path.relpath(os.path.normpath(path), pipelines_path)
    return rel.replace("\\", "/")


def _resolve_production_ddl_paths(
    tables: list[str], inventory: dict, pipelines_path: str
) -> list[str]:
    paths: list[str] = []
    seen: set[str] = set()
    for table_name in tables:
        table_ref = inventory.get(table_name)
        if not table_ref or not table_ref.get("ddl_ref"):
            logger.debug(f"No ddl_ref for table {table_name}")
            continue
        ddl_ref = table_ref["ddl_ref"]
        absolute_path = from_pipeline_to_absolute(ddl_ref)
        if not os.path.exists(absolute_path):
            logger.debug(f"Production DDL file does not exist: {absolute_path}")
            continue
        relative_path = _path_relative_to_pipelines(ddl_ref, pipelines_path)
        if relative_path not in seen:
            seen.add(relative_path)
            paths.append(relative_path)
    return paths


def _ddl_stem_from_inventory_table(table_name: str, inventory: dict) -> set[str]:
    """Return table name and DDL file stem aliases used in unit-test foundations."""
    aliases = {table_name}
    table_ref = inventory.get(table_name)
    if not table_ref:
        return aliases
    ddl_ref = table_ref.get("ddl_ref", "")
    stem = os.path.splitext(os.path.basename(ddl_ref))[0]
    if stem.lower().startswith("ddl."):
        stem = stem[4:]
    aliases.add(stem)
    return aliases


def _foundation_matches_impacted_table(
    foundation_table_name: str,
    impacted_names: set[str],
    inventory: dict,
) -> bool:
    if foundation_table_name in impacted_names:
        return True
    for impacted in impacted_names:
        if foundation_table_name in _ddl_stem_from_inventory_table(impacted, inventory):
            return True
        if impacted.endswith(foundation_table_name):
            return True
    return False


def _collect_unit_test_ddl_paths(
    pipelines_path: str,
    impacted_names: set[str],
    inventory: dict,
) -> list[str]:
    paths: list[str] = []
    seen: set[str] = set()
    pattern = os.path.join(pipelines_path, "**", "tests", TEST_DEFINITION_FILE_NAME)
    for definition_path in glob.glob(pattern, recursive=True):
        tests_folder = os.path.dirname(definition_path)
        table_folder = os.path.dirname(tests_folder)
        try:
            with open(definition_path, "r") as f:
                test_definition = SLTestDefinition.model_validate(yaml.safe_load(f))
        except Exception as e:
            logger.debug(f"Skipping {definition_path}: {e}")
            continue
        for foundation in test_definition.foundations:
            if not _foundation_matches_impacted_table(
                foundation.table_name, impacted_names, inventory
            ):
                continue
            ddl_path = os.path.normpath(
                os.path.join(table_folder, foundation.ddl_for_test.lstrip("./"))
            )
            if not os.path.exists(ddl_path):
                logger.debug(f"Unit test DDL file does not exist: {ddl_path}")
                continue
            relative_path = _path_relative_to_pipelines(ddl_path, pipelines_path)
            if relative_path not in seen:
                seen.add(relative_path)
                paths.append(relative_path)
    return paths


def _resolve_foundation_inventory_table(
    foundation_table_name: str, inventory: dict
) -> str | None:
    """Map a test_definitions foundation name to an inventory table key."""
    if foundation_table_name in inventory:
        return foundation_table_name
    for table_name in inventory:
        if foundation_table_name in _ddl_stem_from_inventory_table(table_name, inventory):
            return table_name
        if table_name.endswith(foundation_table_name):
            return table_name
    return None


def _sync_foundation_ut_ddl_from_production(
    ddl_modified_tables: list[str],
    pipelines_path: str,
    inventory: dict,
    post_fix_unit_test: str,
) -> list[str]:
    """Rewrite foundation unit-test DDL files from production DDL for modified tables."""
    updated_paths: list[str] = []
    seen: set[str] = set()
    foundation_tables = set(ddl_modified_tables)
    pattern = os.path.join(pipelines_path, "**", "tests", TEST_DEFINITION_FILE_NAME)

    for definition_path in glob.glob(pattern, recursive=True):
        tests_folder = os.path.dirname(definition_path)
        table_folder = os.path.dirname(tests_folder)
        try:
            with open(definition_path, "r") as f:
                test_definition = SLTestDefinition.model_validate(yaml.safe_load(f))
        except Exception as e:
            logger.debug(f"Skipping {definition_path}: {e}")
            continue

        for foundation in test_definition.foundations:
            if not _foundation_matches_impacted_table(
                foundation.table_name, foundation_tables, inventory
            ):
                continue
            inventory_table = _resolve_foundation_inventory_table(
                foundation.table_name, inventory
            )
            if not inventory_table:
                logger.warning(
                    f"Foundation {foundation.table_name} has no inventory match; skipping UT DDL sync"
                )
                continue

            table_ref = inventory[inventory_table]
            production_ddl_path = from_pipeline_to_absolute(table_ref["ddl_ref"])
            if not os.path.exists(production_ddl_path):
                logger.warning(f"Production DDL not found: {production_ddl_path}")
                continue

            ut_ddl_path = os.path.normpath(
                os.path.join(table_folder, foundation.ddl_for_test.lstrip("./"))
            )
            with open(production_ddl_path, "r") as f:
                ddl_sql_content = f.read()
            ddl_sql_content = ddl_sql_content.replace(
                inventory_table,
                f"{inventory_table}{post_fix_unit_test}",
            )
            create_folder_if_not_exist(os.path.dirname(ut_ddl_path))
            with open(ut_ddl_path, "w") as f:
                f.write(ddl_sql_content)

            relative_path = _path_relative_to_pipelines(ut_ddl_path, pipelines_path)
            if relative_path not in seen:
                seen.add(relative_path)
                updated_paths.append(relative_path)
                logger.info(
                    f"Updated foundation UT DDL for {foundation.table_name} -> {relative_path}"
                )

    return sorted(updated_paths)


def _add_children_to_process_files(file_info: ModifiedFileInfo, to_process_tables: list[ModifiedFileInfo], inventory: dict):
    """
    Add the children of the table to the list of tables to process
    """
    table_ref = inventory[file_info.table_name]
    if not table_ref:
        logger.error(f"Error: table {file_info.table_name} not found in inventory")
        return
    pipeline_definition = read_pipeline_definition_from_file(table_ref['table_folder_name'] + "/" + PIPELINE_JSON_FILE_NAME)
    if not pipeline_definition:
        logger.error(f"Error: pipeline definition not found for table {file_info.table_name}")
        return
    for child in pipeline_definition.children:
        to_process_tables.append(ModifiedFileInfo(table_name=child.table_name,
                                                  file_modified_url=child.dml_ref,
                                                  same_sql_content=False,
                                                  running=False,
                                                  new_table_name=child.table_name))
def _change_version_in_ddl(fname: str,
                           old_table_name: str,
                           default_version: str):
    parser = SQLparser()
    fname = from_pipeline_to_absolute(fname)
    new_table_name = _build_new_table_name(old_table_name, default_version)
    with open(fname, 'r') as f:
        sql_content = f.read()
        parsed_table_name = parser.extract_table_name_from_create_statement(sql_content)
        if parsed_table_name == old_table_name:
            sql_content = sql_content.replace(parsed_table_name,new_table_name,1) # first occurence is in CREATE TABLE line
        else:
            print(f"❌ Error: table name {parsed_table_name} does not match {old_table_name} in {fname}")
            logger.error(f"❌ Error: table name {parsed_table_name} does not match {old_table_name} in {fname}")
            return
        with open(fname, 'w') as f2:
            f2.write(sql_content)
        logger.info("-"*10 +f"\n{sql_content}\n" + "-"*10)

def _replace_table_name_in_sql_clauses(sql_content: str, old_table_name: str, new_table_name: str) -> str:
    """
    Replace table name in FROM, JOIN, and INSERT INTO clauses.
    Also replaces implicit table aliases (tablename.column) when no explicit AS alias is provided.

    Args:
        sql_content: The SQL content to modify
        old_table_name: The table name to replace
        new_table_name: The new table name

    Returns:
        Modified SQL content with table name replaced in appropriate contexts
    """
    result = sql_content

    # Step 1: Find all FROM/JOIN occurrences and check if they have explicit aliases
    # Pattern to match table references: FROM/JOIN tablename [AS alias]
    table_ref_pattern = rf'\b(FROM|(?:INNER\s+|LEFT\s+|RIGHT\s+|FULL\s+|CROSS\s+)?JOIN)\s+`?{re.escape(old_table_name)}`?\s+(?:AS\s+(\w+))?'

    # Check if there's an explicit alias defined
    has_explicit_alias = False
    matches = re.finditer(table_ref_pattern, sql_content, re.IGNORECASE)
    for match in matches:
        if match.group(2):  # Group 2 is the alias name after AS
            has_explicit_alias = True
            break

    # Step 2: Replace table name in FROM clause
    result = re.sub(
        rf'(\bFROM\s+)(`?{re.escape(old_table_name)}`?)(\b)',
        rf'\g<1>{new_table_name}\g<3>',
        result,
        flags=re.IGNORECASE
    )

    # Step 3: Replace table name in JOIN clauses
    result = re.sub(
        rf'(\b(?:INNER\s+|LEFT\s+|RIGHT\s+|FULL\s+|CROSS\s+)?JOIN\s+)(`?{re.escape(old_table_name)}`?)(\b)',
        rf'\g<1>{new_table_name}\g<3>',
        result,
        flags=re.IGNORECASE
    )

    # Step 4: Replace table name in INSERT INTO clause
    result = re.sub(
        rf'(\bINSERT\s+INTO\s+)(`?{re.escape(old_table_name)}`?)(\b)',
        rf'\g<1>{new_table_name}\g<3>',
        result,
        flags=re.IGNORECASE
    )

    # Step 5: If no explicit alias, replace implicit table alias references (tablename.column)
    if not has_explicit_alias:
        # Replace tablename. with newtablename. in column references
        # Use word boundary before table name and require a dot after it
        result = re.sub(
            rf'\b{re.escape(old_table_name)}\.',
            f'{new_table_name}.',
            result,
            flags=re.IGNORECASE
        )

    return result


def _change_version_in_dml(processed_files: set[ModifiedFileInfo], fname, table_name: str, version: str):
    """
    Change the version of the sql content
    """

    parser = SQLparser()
    fname = from_pipeline_to_absolute(fname)
    updated = False
    processed_table_names = [file_info.table_name for file_info in processed_files]
    with open(fname, 'r') as f:
        sql_content = f.read()
        referenced_table_names = parser.extract_table_references(sql_content)
        for referenced_table_name in referenced_table_names:
            if referenced_table_name in processed_table_names:
                new_referenced_table_name = _build_new_table_name(referenced_table_name, version)
                # Use smart replacement that only replaces in FROM/JOIN clauses
                sql_content = _replace_table_name_in_sql_clauses(sql_content, referenced_table_name, new_referenced_table_name)
                updated = True
    if updated:
        with open(fname, 'w') as f:
            f.write(sql_content)
    logger.info("-"*10 +f"\n{sql_content}\n" + "-"*10)

def _update_version_in_current_ddl_dml(currentfile_info: ModifiedFileInfo,
                               processed_files: set[ModifiedFileInfo],
                               default_version: str,
                               inventory: dict):
    """
    Update the version of the current ddl and dml files for the given table name
    """
    try:
        table_ref = inventory[currentfile_info.table_name]
    except KeyError:
        logger.error(f"Error: table {currentfile_info.table_name} not found in inventory")
        return
    pipeline_definition = read_pipeline_definition_from_file(table_ref['table_folder_name'] + "/" + PIPELINE_JSON_FILE_NAME)
    if not pipeline_definition:
        logger.error(f"Error: pipeline definition not found for table {currentfile_info.table_name}")
        return
    if currentfile_info not in processed_files:
        processed_files.add(currentfile_info)
        _change_version_in_ddl(pipeline_definition.ddl_ref, currentfile_info.table_name, default_version)
        _change_version_in_dml(processed_files, pipeline_definition.dml_ref, currentfile_info.table_name, default_version)
        logger.info(f"Updated version in {pipeline_definition.ddl_ref} and {pipeline_definition.dml_ref}")


def _create_terraform_skeleton(project_folder: str):
    logger.info(f"create_terraform_skeleton({project_folder})")
    iac_folder = os.path.join(project_folder, "IaC")
    create_folder_if_not_exist(iac_folder)
    create_folder_if_not_exist(os.path.join(iac_folder, "dev"))
    create_folder_if_not_exist(os.path.join(iac_folder, "prod"))
    project_name = Path(project_folder).name
    env = Environment(loader=PackageLoader("shift_left.core", "templates"))
    tf_provider_tmpl = env.get_template("tf_provider.jinja")
    context = {
        "project_name": project_name,
        "environment": "demo",
    }
    dev_folder = os.path.join(iac_folder, "dev")
    providers_tf = os.path.join(dev_folder, "providers.tf")
    with open(providers_tf, "w") as f:
        f.write(tf_provider_tmpl.render(context))
    tf_confluent_tmpl = env.get_template("tf_confluent.jinja")
    confluent_tf = os.path.join(dev_folder, "confluent.tf")
    with open(confluent_tf, "w") as f:
        f.write(tf_confluent_tmpl.render(context))
    tf_var_tmpl = env.get_template("tf_variables.jinja")
    variables_tf = os.path.join(dev_folder, "variables.tf")
    with open(variables_tf, "w") as f:
        f.write(tf_var_tmpl.render(context))
    tf_vars = env.get_template("tf_terraform.tfvars.jinja")
    variables_tfvars = os.path.join(dev_folder, "terraform.tfvars.example")
    with open(variables_tfvars, "w") as f:
        f.write(tf_vars.render(context))
    output_tmpl = env.get_template("tf_outputs.jinja")
    outputs_tf = os.path.join(dev_folder, "outputs.tf")
    with open(outputs_tf, "w") as f:
        f.write(output_tmpl.render(context))

def _extract_table_name_from_path(file_path: str) -> str:
    """Extract table name from file path.

    Attempts to extract a meaningful table name from various file path patterns:
    - For SQL files: extracts filename without extension
    - For pipeline paths: attempts to extract table name from directory structure

    Args:
        file_path: The file path to extract table name from

    Returns:
        Extracted table name or filename without extension as fallback
    """
    path = Path(file_path)

    # Remove file extension
    table_name = path.stem

    # Handle common patterns in pipeline directory structures
    if 'pipelines' in path.parts:
        # If it's in a pipelines directory, the parent directory might be the table name
        if len(path.parts) > 1 and path.parent.name != 'pipelines':
            table_name = path.parent.name

    # Clean up common prefixes/suffixes
    table_name = table_name.replace('ddl.', '').replace('dml.', '')

    return table_name

def _initialize_git_repo(project_folder: str):
    print(f"initialize_git_repo({project_folder})")
    try:
        subprocess.run(["git", "init"], check=True, cwd=project_folder)
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to initialize git repository in {project_folder}: {e}")

def _define_dp_structure(pipeline_folder: str):
    data_folder=pipeline_folder + "/data_product_1"
    create_folder_if_not_exist(data_folder)
    _define_kimball_structure(data_folder)


def _define_kimball_structure(pipeline_folder: str):
    create_folder_if_not_exist(pipeline_folder + "/seeds")
    create_folder_if_not_exist(pipeline_folder + "/facts")
    create_folder_if_not_exist(pipeline_folder + "/dimensions")
    create_folder_if_not_exist(pipeline_folder + "/sources")
    create_folder_if_not_exist(pipeline_folder + "/views")

def _add_important_files(project_folder: str):
    logger.info(f"add_important_files({project_folder}")
    for file in ["common.mk"]:
        template_path = importlib.resources.files("shift_left.core.templates").joinpath(file)
        shutil.copyfile(template_path, os.path.join(project_folder, "pipelines", file))
    template_path = importlib.resources.files("shift_left.core.templates").joinpath("set_env_temp")
    shutil.copyfile(template_path, os.path.join(project_folder, "set_env"))
    # Update FLINK_PROJECT in .env file with project folder path
    env_file = os.path.join(project_folder, "set_env")
    with open(env_file, 'r') as f:
        env_content = f.read()
    env_content = env_content.replace("FLINK_PROJECT=", f"FLINK_PROJECT={project_folder}")
    with open(env_file, 'w') as f:
        f.write(env_content)
    template_path = importlib.resources.files("shift_left.core.templates").joinpath(".gitignore_tmpl")
    shutil.copyfile(template_path, os.path.join(project_folder, ".gitignore"))
    template_path = importlib.resources.files("shift_left.core.templates").joinpath("config_tmpl.yaml")
    shutil.copyfile(template_path, os.path.join(project_folder, "config.yaml"))


def _assess_flink_statement_state(table_name: str, file_path: str, sql_content: str) -> Tuple[bool, bool]:
    """
    Assess the state of a Flink statement for the given table.
    Returns (same_sql, running) where same_sql indicates if the SQL is the same as the running statement and running indicates if the statement is running.
    """

    inventory = get_or_build_inventory(os.getenv("PIPELINES"), os.getenv("PIPELINES"), True)
    table_ref = get_table_ref_from_inventory(table_name, inventory)
    if not table_ref:
        print(f"Error: Table {table_name} not found in inventory")
        return False, False
    pipeline_definition = read_pipeline_definition_from_file(table_ref.table_folder_name + "/" + PIPELINE_JSON_FILE_NAME)
    if not pipeline_definition:
        print(f"Error: pipeline definition not found for table {table_name}")
        return False, False
    statement_node = pipeline_definition.to_node()
    flink_statement = statement_mgr.get_statement(statement_node.dml_statement_name)
    if not flink_statement:
        print(f"Error: statement {statement_node.dml_statement_name} not found")
        return True, False
    if isinstance(flink_statement, Statement):
        same_sql = _assess_sql_difference(table_name, sql_content, flink_statement.spec.statement)
        return same_sql, flink_statement.status.phase == "RUNNING"
    else:
        return False, False

def _assess_sql_difference(table_name: str, file_sql_content: str, running_sql_content: str) -> bool:
    """
    Assess the difference between the SQL content on disk and the running statement.
    Returns True if the normalized SQL content is the same after removing comments and normalizing whitespace.
    """
    # Normalize both SQL content strings
    normalized_file_sql = _normalize_sql_content(file_sql_content)
    normalized_running_sql = _normalize_sql_content(running_sql_content)

    logger.info(f"Normalized FILE SQL: \n {normalized_file_sql}")
    logger.info(f"Normalized RUNNING SQL: \n {normalized_running_sql}")

    hash_normalized_file_sql = hashlib.md5(normalized_file_sql.encode('utf-8')).hexdigest()
    hash_normalized_running_sql = hashlib.md5(normalized_running_sql.encode('utf-8')).hexdigest()

    logger.info(f"Hash normalized file SQL: {hash_normalized_file_sql}")
    logger.info(f"Hash normalized running SQL: {hash_normalized_running_sql}")

    return hash_normalized_file_sql == hash_normalized_running_sql


def _normalize_sql_content(sql_content: str) -> str:
    """
    Normalize SQL content by removing comments and normalizing whitespace.

    Args:
        sql_content: Raw SQL content string

    Returns:
        Normalized SQL content string
    """
    if not sql_content:
        return ""

    # Remove SQL comments
    sql_without_comments = _remove_sql_comments(sql_content)

    # Normalize whitespace
    normalized_sql = _normalize_whitespace(sql_without_comments)

    return normalized_sql


def _remove_sql_comments(sql_content: str) -> str:
    """
    Remove SQL comments from the content.
    Handles both single-line comments (--) and multi-line comments (/* */).

    Args:
        sql_content: SQL content with potential comments

    Returns:
        SQL content with comments removed
    """
    # Remove multi-line comments /* ... */
    # Use re.DOTALL to make . match newlines
    sql_content = re.sub(r'/\*.*?\*/', '', sql_content, flags=re.DOTALL)

    # Remove single-line comments -- ...
    # Match -- followed by anything until end of line
    sql_content = re.sub(r'--.*?$', '', sql_content, flags=re.MULTILINE)

    return sql_content


def _normalize_whitespace(sql_content: str) -> str:
    """
    Normalize whitespace in SQL content.

    Args:
        sql_content: SQL content string

    Returns:
        SQL content with normalized whitespace
    """
    # Replace multiple whitespace characters (spaces, tabs, newlines) with single space
    normalized = re.sub(r'\s+', ' ', sql_content)

    # Strip leading and trailing whitespace
    normalized = normalized.strip()

    # Convert to uppercase for case-insensitive comparison
    normalized = normalized.upper()

    return normalized

def _find_all_parent_tables_recursive(table_name: str, inventory: dict, visited: set, tables_to_process: dict):
    """
    Recursively find all parent tables for a given table.

    Args:
        table_name: The table to find parents for
        inventory: The complete inventory of tables
        visited: Set of already visited tables to avoid circular dependencies
        tables_to_process: Dictionary to accumulate all tables that need processing
    """
    if table_name in visited:
        # Avoid circular dependencies
        logger.debug(f"Table {table_name} already visited, skipping to avoid circular dependency")
        return

    visited.add(table_name)

    # Get table reference from inventory
    if table_name not in inventory:
        logger.warning(f"Table {table_name} not found in inventory")
        return

    tableRef = inventory[table_name]
    tables_to_process[table_name] = tableRef['table_folder_name']

    # Read pipeline definition to find parents
    pipeline_definition = read_pipeline_definition_from_file(
        os.path.join(tableRef['table_folder_name'], PIPELINE_JSON_FILE_NAME)
    )

    if pipeline_definition and pipeline_definition.parents:
        logger.debug(f"Found {len(pipeline_definition.parents)} parents for table {table_name}")
        for parent in pipeline_definition.parents:
            logger.debug(f"Processing parent {parent.table_name} for table {table_name}")
            # Recursively process each parent
            _find_all_parent_tables_recursive(parent.table_name, inventory, visited, tables_to_process)


def _build_new_table_name(old_table_name: str, version: str) -> str:
    version_pattern = re.compile(r'_v(\d+)$')
    match = version_pattern.search(old_table_name)
    if match:
        existing_version = match.group(1)  # Extract the numerical value
        # Remove the existing version suffix before adding the new version
        base_table_name = version_pattern.sub('', old_table_name)
        return f"{base_table_name}_v{str(int(existing_version)+1)}"
    else:
        return f"{old_table_name}{version}"
