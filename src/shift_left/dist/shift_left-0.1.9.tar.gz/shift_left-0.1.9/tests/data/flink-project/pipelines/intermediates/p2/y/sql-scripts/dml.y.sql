INSERT INTO y
VALUES ('key_y_1', 'v_y_1', 'x_key_1'),
('key_y_2', 'v_y_2', 'x_key_2');
