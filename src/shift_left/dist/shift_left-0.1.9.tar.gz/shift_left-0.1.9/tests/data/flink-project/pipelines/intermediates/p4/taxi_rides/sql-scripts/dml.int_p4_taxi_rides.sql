INSERT INTO int_p4_taxi_rides
SELECT 
-- part to select stuff
FROM src_table
WHERE -- where condition or remove it