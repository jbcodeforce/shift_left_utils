insert into int_table_2
values ('order_3', 'product_2', 'user_id_3',10),
  ('order_4', 'product_2', 'user_id_4',4),
  ('order_5', 'product_2', 'user_id_5',10),
  ('order_6', 'product_1', 'user_id_3',5);