# Running integration tests

Before running any integration tests it is important to set the environment variables for API_KEYS and SECRETS for Confluent Cloud, Flink, and Kafka.

