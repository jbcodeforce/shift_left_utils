INSERT INTO int_p1_table_2
SELECT 
*
FROM src_p1_table_2;