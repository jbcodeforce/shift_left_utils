uv tool uninstall shift_left
uv tool install shift_left@dist/shift_left-$1-py3-none-any.whl
uv tool list