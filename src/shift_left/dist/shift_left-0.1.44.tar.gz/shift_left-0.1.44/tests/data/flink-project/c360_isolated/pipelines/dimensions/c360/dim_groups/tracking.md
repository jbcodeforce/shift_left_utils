## Fact Table: c360_dim_groups

Status date:

Context:

-- Process file: 

## DDL and DML for fact table status

* DDL:
* DML:

STATUS: MIGRATED

## Direct Dependencies found



## Tests

* Get source data from <> -> 
* Verify there is no duplicate in output table  ->