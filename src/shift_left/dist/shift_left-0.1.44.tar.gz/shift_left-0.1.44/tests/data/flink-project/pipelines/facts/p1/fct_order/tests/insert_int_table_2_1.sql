insert into int_table_2_ut
values ('order_1', 'product_1', 'user_id_5',10),
 ('order_2', 'product_1', 'user_id_6',15);