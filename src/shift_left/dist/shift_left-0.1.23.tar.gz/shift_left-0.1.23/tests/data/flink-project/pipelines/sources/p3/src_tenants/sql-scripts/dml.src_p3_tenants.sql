INSERT INTO src_p3_tenants
SELECT 
-- part to select stuff
FROM src_table
WHERE -- where condition or remove it