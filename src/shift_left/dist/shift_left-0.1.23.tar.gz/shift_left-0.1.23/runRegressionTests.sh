source set_test_env
uv run pytest tests/ut/utils
uv run pytest tests/ut/core
