INSERT INTO src_table_1
VALUES ("table_1_1", "CODE_01"),
       ("table_1_2", "CODE_02");