INSERT INTO src_table_2
select * from `src_order_raw`;