insert into int_table_1_ut
values ('a','b','c');