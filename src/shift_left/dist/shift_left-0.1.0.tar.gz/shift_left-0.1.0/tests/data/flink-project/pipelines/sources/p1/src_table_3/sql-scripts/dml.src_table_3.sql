INSERT INTO src_table_3
values()