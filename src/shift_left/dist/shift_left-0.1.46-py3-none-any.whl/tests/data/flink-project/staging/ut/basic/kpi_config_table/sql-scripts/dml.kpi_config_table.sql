INSERT INTO kpi_config_table
SELECT 
    dbtable,
    MAX(kpiName) AS kpiname,
    MAX(kpiStatus) AS kpistatus,
    MAX(networkService) AS networkservice,
    MAX(elementType) AS elementtype,
    MAX(interfaceName) AS interfacename
FROM (
    SELECT dbtable, kpiName, kpiStatus, networkService, elementType, interfaceName,
           ROW_NUMBER() OVER (PARTITION BY dbtable ORDER BY $rowtime DESC) as rn
    FROM basic_table_stream
) WHERE rn = 1
GROUP BY dbtable;