INSERT INTO f
SELECT
	d.default_key,
	'f-value' as f_value
FROM d
