INSERT INTO filtering
SELECT 
-- part to select stuff
FROM src_table
WHERE -- where condition or remove it