source ../../set_j9r_env
uv run pytest tests/it/cli
uv run pytest tests/it
