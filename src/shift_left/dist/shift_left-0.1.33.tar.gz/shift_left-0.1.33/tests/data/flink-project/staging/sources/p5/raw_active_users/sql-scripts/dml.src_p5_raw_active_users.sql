
INSERT INTO src_p5_raw_active_users
SELECT
    
    -- change key and add columns
FROM ``;