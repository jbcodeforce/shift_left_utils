insert into table_1
(`sid`, `column_1`, `column_2`, `column_3`, `column_4`, `column_5`, `column_6`, `created_by`, `created_date`, `last_modified_by`, `last_modified_date`, `description`, `is_active`)
values
('sid_1', 'column_1_1', 'column_2_1', 'A', 'column_4_1', 'column_5_1', 'column_6_1', 'created_by_1', '2021-01-01', 'last_modified_by_1', '2021-01-01', 'description_1', 'is_active_1'),
('sid_2', 'column_1_2', 'column_2_2', 'B', 'column_4_2', 'column_5_2', 'column_6_2', 'created_by_2', '2021-01-01', 'last_modified_by_2', '2021-01-02', 'description_2', 'is_active_2'),
('sid_3', 'column_1_3', 'column_2_3', 'C', 'column_4_3', 'column_5_3', 'column_6_3', 'created_by_3', '2021-01-01', 'last_modified_by_3', '2021-01-03', 'description_3', 'is_active_3'),
('sid_4', 'column_1_4', 'column_2_4', 'D', 'column_4_4', 'column_5_4', 'column_6_4', 'created_by_4', '2021-01-01', 'last_modified_by_4', '2021-01-04', 'description_4', 'is_active_4'),
('sid_5', 'column_1_5', 'column_2_5', 'F', 'column_4_5', 'column_5_5', 'column_6_5', 'created_by_5', '2021-01-01', 'last_modified_by_5', '2021-01-05', 'description_5', 'is_active_5');