export SL_LLM_BASE_URL=https://openrouter.ai/api/v1
export SL_LLM_MODEL=qwen/qwen3-coder:free