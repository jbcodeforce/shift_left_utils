INSERT INTO src_x
VALUES ('key_x_1', 'v_x_1'),
('key_x_2', 'v_x_2');