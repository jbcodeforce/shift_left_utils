insert into  a_table
SELECT
    a,b,c
FROM   int_p5_a;