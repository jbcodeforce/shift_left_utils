INSERT INTO src_b
VALUES ('key_b_1', 'v_b_1'),
('key_b_2', 'v_b_2');