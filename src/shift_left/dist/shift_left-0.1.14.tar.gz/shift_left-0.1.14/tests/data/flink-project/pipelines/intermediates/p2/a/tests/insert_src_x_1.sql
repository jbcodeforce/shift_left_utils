insert into src_x_ut
(default_key, x_value)
values
('default_key_1', 'x_value_1'),
('default_key_2', 'x_value_2'),
('default_key_3', 'x_value_3'),
('default_key_4', 'x_value_4'),
('default_key_5', 'x_value_5');

