
INSERT INTO src_s2
SELECT
    
    -- change key and add columns
FROM ``;