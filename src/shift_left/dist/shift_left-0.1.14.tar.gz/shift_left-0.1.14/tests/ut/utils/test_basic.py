import os
import pytest
from pydantic import BaseModel
from typing import List
from shift_left.core.pipeline_mgr import read_pipeline_definition_from_file
from shift_left.core.pipeline_mgr import PIPELINE_JSON_FILE_NAME
from datetime import datetime
from shift_left.core.flink_statement_model import FlinkStatementNode
import shift_left.core.statement_mgr as statement_mgr
import shift_left.core.compute_pool_mgr as compute_pool_mgr
from shift_left.core.utils.app_config import get_config

class TableInfo(BaseModel):
    table_name: str = ""
    type: str = ""
    statement_name: str = ""
    status: str = ""
    created_at: str = ""
    compute_pool_id: str = ""
    compute_pool_name: str = ""

class TableReport(BaseModel):
    product_name: str = ""
    environment_id: str = ""
    catalog_name: str = ""
    database_name: str = ""
    tables: List[TableInfo] = []

def test_os_walk():
    table_report = TableReport()
    table_report.product_name = 'aqem'
    table_report.environment_id = get_config().get('environment_id')
    table_report.catalog_name = get_config().get('flink').get('catalog_name')
    table_report.database_name = get_config().get('flink').get('database_name')
    compute_pool_list = compute_pool_mgr.get_compute_pool_list()
    

    for root, dirs, files in os.walk(os.getenv("PIPELINES")):
        if 'aqem' in root:
            print(root)
            if 'sql-scripts' in dirs:
                file_path=root + "/" + PIPELINE_JSON_FILE_NAME
                pipeline_def = read_pipeline_definition_from_file(file_path)
                if pipeline_def:
                    node: FlinkStatementNode = pipeline_def.to_node()
                    node.existing_statement_info = statement_mgr.get_statement_status(node.dml_statement_name)
                    pool = compute_pool_mgr.get_compute_pool_with_id(compute_pool_list, node.compute_pool_id)
                    table_info = TableInfo()
                    table_info.table_name = node.table_name
                    table_info.type = node.type
                    table_info.statement_name = node.dml_statement_name
                    table_info.status = node.existing_statement_info.status_phase
                    table_info.compute_pool_id = node.existing_statement_info.compute_pool_id
                    table_info.compute_pool_name = pool.name
                    table_info.created_at = node.existing_statement_info.created_at
                    table_report.tables.append(table_info)
    print(table_report.model_dump_json(indent=4))
    table_count=0
    running_count=0
    non_running_count=0
    for table in table_report.tables:
        print(f"{table.table_name},{table.statement_name},{table.status},{table.compute_pool_id},{table.created_at}")
        if table.status == 'RUNNING':
            running_count+=1
        else:
            non_running_count+=1
        table_count+=1
    print(f"Total tables: {table_count}")
    print(f"Running tables: {running_count}")
    print(f"Non running tables: {non_running_count}")
    
    