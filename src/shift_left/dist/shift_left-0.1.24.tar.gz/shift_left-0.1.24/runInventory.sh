uv run python src/shift_left/cli.py table build-inventory $PIPELINES
