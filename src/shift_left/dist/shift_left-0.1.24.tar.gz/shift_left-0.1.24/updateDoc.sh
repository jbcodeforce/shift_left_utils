uv run typer src/shift_left/cli.py utils docs --output ../../docs/command.md
