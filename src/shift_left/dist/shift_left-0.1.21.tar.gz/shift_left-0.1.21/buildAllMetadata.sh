uv run python src/shift_left/cli.py pipeline build-all-metadata $PIPELINES
