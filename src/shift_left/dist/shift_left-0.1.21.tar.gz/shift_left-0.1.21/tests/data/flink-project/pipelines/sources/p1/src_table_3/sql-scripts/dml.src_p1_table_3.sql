-- mock external producer.
INSERT INTO src_p1_table_3
values('account_1', 'user_id_1', 'account of bob', 100),
('account_2', 'user_id_2', 'account of bill', 200),
('account_3', 'user_id_3', 'account of julie', 300),
('account_4', 'user_id_4', 'account of caroline', 400),
('account_5', 'user_id_5', 'account of mathieu', 200);
