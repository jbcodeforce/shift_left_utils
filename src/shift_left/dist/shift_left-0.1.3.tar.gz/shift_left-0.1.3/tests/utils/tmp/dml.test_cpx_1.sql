insert into int_mx_vaults

with vaults as (
    select
        vault_id
        , vault_name
        , infocard_id
        , __db
    from `int_vaults`
    )
, master_template as (
    select
        tenantId
        , masterTemplateId
        , masterTemplateDetails
    from `src_mx_master_template`
    )
, expandedMasterDetails as (
    select
        tenantId
        , masterTemplateId
        , masterTemplateDetails.infoCardId as infocard_id
    from master_template      
    )
, final as (
    select 
        e.tenantId as tenant_id
        , e.masterTemplateId as master_template_id
        , e.infocard_id as infocard_id
        , v.vault_id
        , v.vault_name
    from expandedMasterDetails as e
    left join vaults as v
        on e.tenantId = v.__db
        and e.infocard_id = v.infocard_id
)

select * from final