INSERT INTO it2
SELECT 
-- part to select stuff
FROM src_table
WHERE -- where condition or remove it