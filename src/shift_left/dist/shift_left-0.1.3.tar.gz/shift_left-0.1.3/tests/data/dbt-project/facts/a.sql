insert into  a
SELECT
    a,b,c
FROM   it1;