uv run shift_left pipeline build-all-metadata $PIPELINES
