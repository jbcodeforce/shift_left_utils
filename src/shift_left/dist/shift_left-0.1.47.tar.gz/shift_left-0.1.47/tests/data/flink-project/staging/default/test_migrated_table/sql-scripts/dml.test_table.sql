INSERT INTO test_table
SELECT *
FROM test_table;