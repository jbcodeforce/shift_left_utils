-- mock external producer.
INSERT INTO src_table_1
VALUES ('user_id_1','bob'),
('user_id_2','bill'),
('user_id_3','julie'),
('user_id_4','caroline'),
('user_id_5','mathieu');