uv run shift_left table build-inventory $PIPELINES
