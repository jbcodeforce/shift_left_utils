uv run typer cli.py utils docs --output ../../docs/command.md
