insert into BASIC_TABLE_STREAM
(`kpiName`, `kpiStatus`, `highMetricThreshold`, `lowMetricThreshold`, `networkService`, `elementType`, `interfaceName`, `dbTable`)
values
('kpiName_1', 'kpiStatus_1', 'highMetricThreshold_1', 'lowMetricThreshold_1', 'networkService_1', 'elementType_1', 'interfaceName_1', 'dbTable_1'),
('kpiName_2', 'kpiStatus_2', 'highMetricThreshold_2', 'lowMetricThreshold_2', 'networkService_2', 'elementType_2', 'interfaceName_2', 'dbTable_2'),
('kpiName_3', 'kpiStatus_3', 'highMetricThreshold_3', 'lowMetricThreshold_3', 'networkService_3', 'elementType_3', 'interfaceName_3', 'dbTable_3'),
('kpiName_4', 'kpiStatus_4', 'highMetricThreshold_4', 'lowMetricThreshold_4', 'networkService_4', 'elementType_4', 'interfaceName_4', 'dbTable_4'),
('kpiName_5', 'kpiStatus_5', 'highMetricThreshold_5', 'lowMetricThreshold_5', 'networkService_5', 'elementType_5', 'interfaceName_5', 'dbTable_5');

