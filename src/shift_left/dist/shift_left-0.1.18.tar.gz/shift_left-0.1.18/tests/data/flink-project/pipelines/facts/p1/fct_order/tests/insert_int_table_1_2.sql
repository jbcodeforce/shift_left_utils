insert into int_table_1_ut
values 
('user_id_3', 'julie', 'account_1', 'account of julie', 300),
('user_id_4', 'caroline', 'account_4', 'account of caroline', 400),
('user_id_5', 'mathieu', 'account_5', 'account of mathieu', 200);