INSERT INTO w2_processing
SELECT 
-- part to select stuff
FROM src_table
WHERE -- where condition or remove it