INSERT INTO geolocation
SELECT 
-- part to select stuff
FROM src_table
WHERE -- where condition or remove it