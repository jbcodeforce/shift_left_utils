-- Integration test synthetic data for raw_tenants
-- Generated on: 2025-09-23T15:55:53.929622+00:00
-- Unique test ID: e7a9bf58-f4ee-4126-bb5f-75f74d2c6671
INSERT INTO raw_tenants_it (key
) VALUES (
    -- Add appropriate test values here
'key_1'
);
