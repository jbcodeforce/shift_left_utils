CREATE TABLE IF NOT EXISTS kpi_config_table (
  `dbTable` STRING,
  kpiName STRING,
  kpiStatus STRING,
  networkService STRING,
  elementType STRING,
  interfaceName STRING,
  sourceName STRING,
  PRIMARY KEY (`dbTable`) NOT ENFORCED
) WITH (
  'key.format' = 'json',
  'value.format' = 'json',
  'scan.startup.mode' = 'earliest-offset',
  'connector' = 'kafka',
  'properties.bootstrap.servers' = 'your_kafka_broker:9092',
  'properties.group.id' = 'flink_consumer_group'
) AS
SELECT
  `dbTable`,
  kpiName,
  kpiStatus,
  networkService,
  elementType,
  interfaceName,
  sourceName
FROM
  (
    SELECT
      *,
      ROW_NUMBER() OVER (
        PARTITION BY `dbTable`
        ORDER
          BY `rowtime` DESC
      ) AS rn
    FROM
      basic_table_stream
  )
WHERE
  rn = 1;