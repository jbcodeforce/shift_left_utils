export SL_LLM_BASE_URL=http://localhost:1337/v1
export SL_LLM_MODEL=qwen-coder-30b-a3b-instruct-mlx-4bit
export SL_LLM_API_KEY=osaurus_test_key
