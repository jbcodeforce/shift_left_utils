CREATE TABLE IF NOT EXISTS engineers (
    `name` STRING,
    `id` BIGINT,
    `department` STRING,
    PRIMARY KEY (`id`) NOT ENFORCED
) DISTRIBUTED BY HASH(`id`) INTO 1 BUCKETS WITH (
    'value.format' = 'json-registry',
    'value.json-registry.schema-context' = '.flink-dev',
    'value.fields-include' = 'all',
    'scan.startup.mode' = 'earliest-offset',
    'changelog.mode' = 'append',
    'kafka.retention.time' = '0',
    'kafka.producer.compression.type' = 'snappy',
    'scan.bounded.mode' = 'unbounded'
);