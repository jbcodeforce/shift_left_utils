insert into src_common_tenant_ut (`tenant_id`, `tenant_name`, `tenant_description`, `tenant_status`, `tenant_created_at`, `tenant_updated_at`)
values
('tenant_id_1', 'tenant_name_1', 'tenant_description_1', 'tenant_status_1', TIMESTAMP '2021-01-01 00:00:00', TIMESTAMP '2021-01-01 00:00:00'),
('tenant_id_2', 'tenant_name_2', 'tenant_description_2', 'tenant_status_2', TIMESTAMP '2021-01-01 00:00:00', TIMESTAMP '2021-01-01 00:00:00'),
('tenant_id_3', 'tenant_name_3', 'tenant_description_3', 'tenant_status_3', TIMESTAMP '2021-01-01 00:00:00', TIMESTAMP '2021-01-01 00:00:00');