uv run typer shift_left/cli.py utils docs --output ../../docs/command.md
