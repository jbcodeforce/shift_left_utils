-- Integration test synthetic data for raw_groups
-- Generated on: 2025-09-23T15:55:53.932466+00:00
-- Unique test ID: e5719e7b-4dc4-4cf1-b5e5-d4886322b629
INSERT INTO raw_groups_it (group_id, tenant_id, group_name, group_type, created_date, is_active
) VALUES (
    -- Add appropriate test values here
'group_id_1', 'tenant_id_1', 'group_name_1', 'group_type_1', 'created_date_1', false
);
