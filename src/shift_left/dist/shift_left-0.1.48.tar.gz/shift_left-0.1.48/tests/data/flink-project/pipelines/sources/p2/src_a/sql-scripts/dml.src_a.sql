INSERT INTO src_a
VALUES ('key_a_1', 'v_a_1', 'key_x_1'),
('key_a_2', 'v_a_2', 'key_x_2');