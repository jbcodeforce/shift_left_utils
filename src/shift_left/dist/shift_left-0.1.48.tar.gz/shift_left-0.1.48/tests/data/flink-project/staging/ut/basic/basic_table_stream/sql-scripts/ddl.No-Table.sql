CREATE STREAM BASIC_TABLE_STREAM (
kpiName VARCHAR,
kpiStatus VARCHAR,
highMetricThreshold INT,
lowMetricThreshold INT,
networkService VARCHAR,
elementType VARCHAR,
interfaceName VARCHAR,
dbTable VARCHAR
) WITH (
kafka_topic = 'stage.kpi_config',
value_format = 'JSON',
partitions = 1
);