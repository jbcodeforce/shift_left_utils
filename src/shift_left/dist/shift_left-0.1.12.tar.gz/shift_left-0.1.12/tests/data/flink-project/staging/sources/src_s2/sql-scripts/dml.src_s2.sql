
INSERT INTO src_s2
SELECT
    -- put here column definitions
    -- change key and add columns
FROM ``;