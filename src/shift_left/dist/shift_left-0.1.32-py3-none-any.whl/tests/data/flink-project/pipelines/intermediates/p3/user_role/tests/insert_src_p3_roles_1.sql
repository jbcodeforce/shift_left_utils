insert into src_p3_roles_ut
(role_id, role_name)
values
('role_id_1', 'role_name_1'),
('role_id_2', 'role_name_2'),
('role_id_3', 'role_name_3'),
('role_id_4', 'role_name_4'),
('role_id_5', 'role_name_5');

