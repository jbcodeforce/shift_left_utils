"""
Copyright 2024-2025 Confluent, Inc.
"""
import unittest
import os
import re
import pathlib
from shift_left.core.utils.sql_parser import (
    SQLparser
)


class TestFileSearch(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.data_dir = pathlib.Path(__file__).parent.parent / "../data"  # Path to the data directory
        os.environ["PIPELINES"] = str(cls.data_dir / "flink-project/pipelines")

    def test_get_table_from_select(self):
        parser = SQLparser()
        query="""
        SELECT * FROM table1
        """
        rep=parser.extract_table_references(query)
        assert rep
        assert "table1" in rep
        assert "Stateless" in parser.extract_upgrade_mode(query)

    def test_get_tables_from_join(self):
        parser = SQLparser()
        query= """
        SELECT a.*, b.name 
        FROM schema1.table1 a 
        JOIN table2 b ON a.id = b.id
        """
        rep=parser.extract_table_references(query)
        assert rep
        assert "schema1.table1" in rep
        assert "table2" in rep
        assert "Stateful" in parser.extract_upgrade_mode(query)

    def test_get_tables_from_inner_join(self):
        parser = SQLparser()
        query= """
        SELECT * 
        FROM table1 t1
        LEFT JOIN schema2.table2 AS t2 ON t1.id = t2.id
        INNER JOIN table3 t3 ON t2.id = t3.id
        """
        rep=parser.extract_table_references(query)
        assert rep
        assert "schema2.table2" in rep
        assert "table1" in rep
        assert "table3" in rep
        assert "Stateful" in parser.extract_upgrade_mode(query)

    def test_get_tables_from_right_join(self):
        parser = SQLparser()
        query=  """
        SELECT * 
        FROM table1
        RIGHT OUTER JOIN table2 ON table1.id = table2.id
        FULL JOIN table3 ON table2.id = table3.id
        """
        rep=parser.extract_table_references(query)
        assert rep
        assert "table2" in rep
        assert "table1" in rep
        assert "table3" in rep
        assert "Stateful" in parser.extract_upgrade_mode(query)

        
    def test_get_tables_without_ctes(self):
        parser = SQLparser()
        query= """
        WITH cte1 AS (
           SELECT a,b,c
           FROM table1
        ),
        cte2 AS (
            SELECT d,b,e
           FROM table2
        )
        SELECT * 
        FROM cte1
        RIGHT OUTER JOIN cte2 ON table1.id = table2.id
        FULL JOIN table3 ON table2.id = table3.id
        CROSS JOIN unnest(split(trim(BOTH '[]' FROM y.target_value),','))  as user_id
        """
        rep=parser.extract_table_references(query)
        assert rep
        assert "table1" in rep
        assert "table2" in rep
        assert not "cte1" in rep
        print(rep)
        assert "Stateful" in parser.extract_upgrade_mode(query)
    

    def test_get_tables_without_ctes(self):
        parser = SQLparser()
        query="""
            -- a comment
        with exam_def as (select * from {{ ref('int_exam_def_deduped') }} )
        ,exam_data as (select * from {{ ref('int_exam_data_deduped') }} )
        ,exam_performance as (select * from {{ ref('int_exam_performance_deduped') }} )
        ,training_data as (select * from {{ ref('int_training_data_deduped') }} )
        """
        rep=parser.extract_table_references(query)
        assert rep
        print(rep)
        assert "Stateless" in parser.extract_upgrade_mode(query)

    def test_extract_table_name_from_insert(self):
        parser = SQLparser()
        query="INSERT INTO mytablename\nSELECT a,b,c\nFROM src_table"
        rep=parser.extract_table_references(query)
        assert rep
        assert "src_table" in rep
        print(rep)
        assert "Stateless" in parser.extract_upgrade_mode(query)


    def test_sql_content_order(self):
        fname = os.getenv("PIPELINES") + "/facts/p1/fct_order/sql-scripts/dml.p1_fct_order.sql"
        with open(fname, "r") as f:
            sql_content = f.read()
            parser = SQLparser()
            referenced_table_names = parser.extract_table_references(sql_content)
            assert len(referenced_table_names) == 3
            assert "Stateful" in parser.extract_upgrade_mode(sql_content)

    def test_stateless_from_dml_ref(self):
        parser = SQLparser()
        fname = os.getenv("PIPELINES") + "/sources/p2/src_a/sql-scripts/dml.src_p2_a.sql"
        with open(fname, "r") as f:
            sql_content = f.read()
            upgrade_mode = parser.extract_upgrade_mode(sql_content)
            assert "Stateless"  == upgrade_mode

    def test_extract_columns_from_ddl(self):
        parser = SQLparser()
        fname = os.getenv("PIPELINES") + "/intermediates/p1/int_test/sql-scripts/ddl.test.sql"
        with open(fname, "r") as f:
            sql_content = f.read()
            columns = parser.parse_sql_columns_to_dict(sql_content)
            assert columns
            assert columns['id'] == {'name': 'id', 'type': 'STRING', 'nullable': False, 'primary_key': True}  
            assert columns['tenant_id'] == {'name': 'tenant_id', 'type': 'STRING', 'nullable': False, 'primary_key': True}
            assert columns['status'] == {'name': 'status', 'type': 'STRING', 'nullable': True, 'primary_key': False}
            assert columns['name'] == {'name': 'name', 'type': 'STRING', 'nullable': True, 'primary_key': False}
            assert columns['type'] == {'name': 'type', 'type': 'STRING', 'nullable': True, 'primary_key': False}
            assert columns['created_by'] == {'name': 'created_by', 'type': 'STRING', 'nullable': True, 'primary_key': False}
            assert columns['created_date'] == {'name': 'created_date', 'type': 'BIGINT', 'nullable': True, 'primary_key': False}

    def test_extract_keys(self):
        sql_statement_multiple = 'PRIMARY KEY(id, name) NOT ENFORCED'
        match_multiple = re.search(r'PRIMARY KEY\((.*?)\)', sql_statement_multiple, re.IGNORECASE)

        if match_multiple:
            column_names_str_multiple = match_multiple.group(1)
            column_names_multiple = [name.strip() for name in column_names_str_multiple.split(',')]
            print(column_names_multiple)
        else:
            print("No primary key found in the statement.")
        sql_statement = 'id STRING NOT NULL, tenant_id STRING NOT NULL, status STRING, name STRING, `type` STRING, created_by STRING, created_date BIGINT, last_modified_by STRING, PRIMARY KEY(id, tenant_id'
        result = re.sub(r'^.*PRIMARY KEY\(', '', sql_statement, flags=re.IGNORECASE)
        print(result)

if __name__ == '__main__':
    unittest.main()