
INSERT INTO src_s1
SELECT
    -- put here column definitions
    -- change key and add columns
FROM `dataplatformcluster.public.notes1`;