insert into int_table_1
values ('user_id_1', 'bob', 'account_1', 'account of bob', 100),
       ('user_id_2','bill', 'account_2', 'account of bill', 200);