info = {
    'spec': {
        'properties': {
            'sql.current-catalog': 'my_catalog',
            'another_prop': 123
        }
    }
}

catalog = info.get('spec', {}).get('properties', {}).get('sql.current-catalog')

if catalog is not None:
    print(f"Current catalog: {catalog}")
else:
    print("Catalog information is missing or None.")

# Example with a missing key
info_missing = {'spec': {}}
catalog_missing = info_missing.get('spec', {}).get('properties', {}).get('sql.current-catalog')
print(f"Catalog (missing): {catalog_missing}")  # Output: None

info_missing = {'spec': {'properties': None}}
if 'properties' in info_missing.get('spec') and info_missing.get('spec').get('properties'):
    catalog_missing = info_missing.get('spec', {}).get('properties', {}).get('sql.current-catalog')
    print(f"Catalog (missing): {catalog_missing}") 

info_missing = {}
catalog_missing = info_missing.get('spec', {}).get('properties', {}).get('sql.current-catalog')
print(f"Catalog (missing): {catalog_missing}") 