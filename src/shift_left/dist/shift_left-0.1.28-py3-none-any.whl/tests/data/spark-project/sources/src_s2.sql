insert into src_s2 (id,c);
