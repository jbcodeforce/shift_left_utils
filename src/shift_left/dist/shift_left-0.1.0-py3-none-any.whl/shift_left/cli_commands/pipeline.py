import typer
from rich import print
from rich.tree import Tree
from rich.console import Console
from shift_left.core.pipeline_mgr import build_pipeline_definition_from_table, walk_the_hierarchy_for_report_from_table, delete_metada_files
from typing_extensions import Annotated
import json
import os

"""
Manage a pipeline entity:
- build the inventory of tables
- generate pipeline reports
"""
app = typer.Typer(no_args_is_help=True)



@app.command()
def build_metadata(dml_file_name:  Annotated[str, typer.Argument()], 
             pipeline_path: Annotated[str, typer.Argument(envvar=["PIPELINES"])]):
    """
    Build a pipeline from a sink table: add or update {} each table in the pipeline
    """
    print(f"Build pipeline from sink table {dml_file_name}")
    if pipeline_path and pipeline_path != os.getenv("PIPELINES"):
        print(f"Using pipeline path {pipeline_path}")
        os.environ["PIPELINES"] = pipeline_path

    build_pipeline_definition_from_table(dml_file_name, pipeline_path)

@app.command()
def delete_metadata(path_from_where_to_delete:  Annotated[str, typer.Argument()]):
    """
    Delete a pipeline definitions from a given folder
    """
    print(f"Delete pipeline definition from {path_from_where_to_delete}")
    delete_metada_files(path_from_where_to_delete)


@app.command()
def report(table_name: Annotated[str, typer.Argument(help="The table name (folder name) containing pipeline_definition.json")],
          inventory_path: Annotated[str, typer.Argument(envvar=["PIPELINES"], help="Path to the inventory folder")]):
    """
    Generate a report showing the pipeline hierarchy for a given table using its pipeline_definition.json
    """
    console = Console()
    print(f"Generating pipeline report for table {table_name}")
    try:
        pipeline_def=walk_the_hierarchy_for_report_from_table(table_name,inventory_path )
    except Exception as e:
        print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    # Create a rich tree for visualization
    tree = Tree(f"[bold blue]{pipeline_def.table_name}[/bold blue]")
    
    def add_nodes_to_tree(node_data, tree_node):
        if node_data.parents:
            for parent in node_data.parents:
                parent_node = tree_node.add(f"[green]{parent['table_name']}[/green]")
                # Add file references
                if parent.get('dml_ref'):
                    parent_node.add(f"[dim]DML: {parent['dml_ref']}[/dim]")
                if parent.get('ddl_ref'):
                    parent_node.add(f"[dim]DDL: {parent['ddl_ref']}[/dim]")
    
    # Add the root node details
    tree.add(f"[dim]Type: {pipeline_def.type}[/dim]")
    tree.add(f"[dim]DML: {pipeline_def.dml_ref}[/dim]")
    tree.add(f"[dim]DDL: {pipeline_def.ddl_ref}[/dim]")
    
    # Add parent nodes
    add_nodes_to_tree(pipeline_def, tree)
    
    # Print the tree
    console.print("\n[bold]Pipeline Hierarchy:[/bold]")
    console.print(tree)