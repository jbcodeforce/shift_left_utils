insert into src_p3_tenants_ut
(id, name, description, created_at)
values
('id_1', 'name_1', 'description_1', 'created_at_1'),
('id_2', 'name_2', 'description_2', 'created_at_2'),
('id_3', 'name_3', 'description_3', 'created_at_3'),
('id_4', 'name_4', 'description_4', 'created_at_4'),
('id_5', 'name_5', 'description_5', 'created_at_5');

