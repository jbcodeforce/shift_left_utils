source set_test_env
uv run pytest tests/it/cli
uv run pytest tests/it
