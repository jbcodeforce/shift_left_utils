insert into src_p2_a_ut
(`default_key`, `a_value`, `x_key`)
values
('default_key_1', 'a_value_1', 'x_key_1'),
('default_key_2', 'a_value_2', 'x_key_2'),
('default_key_3', 'a_value_3', 'x_key_3');

