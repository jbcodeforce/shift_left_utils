# Flink references

This folder includes Flink statements matching the ksql ones from the sources folder.

## Mapping

* ksqlDB files are under sources
* Matching flink statements were tested on Confluent Cloud for flink

| ksqldb file | Flink files | DML |
| --- | --- | --- | 
| ddl-basic-table.ksql | ddl.basic_table.sql | None |
