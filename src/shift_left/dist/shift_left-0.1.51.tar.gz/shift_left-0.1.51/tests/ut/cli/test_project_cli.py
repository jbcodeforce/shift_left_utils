"""
Copyright 2024-2025 Confluent, Inc.
"""
import unittest
import pathlib
import os
import shutil
import tempfile
import json
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner

_TESTS_ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
os.environ.setdefault("SL_CONFIG_FILE", str(_TESTS_ROOT / "config.yaml"))
# Dummy credentials so get_config()/validate_config succeed when pytest imports CLI modules
# (integration_test_mgr and others call get_config() at import time).
if not os.environ.get("SL_CONFLUENT_CLOUD_API_KEY"):
    os.environ.setdefault("SL_KAFKA_API_KEY", "test")
    os.environ.setdefault("SL_KAFKA_API_SECRET", "test")
    os.environ.setdefault("SL_CONFLUENT_CLOUD_API_KEY", "test")
    os.environ.setdefault("SL_CONFLUENT_CLOUD_API_SECRET", "test")
    os.environ.setdefault("SL_FLINK_API_KEY", "test")
    os.environ.setdefault("SL_FLINK_API_SECRET", "test")
    os.environ.setdefault("SL_CCLOUD_KAFKA_CLUSTER_ID", "lkc-test")
    os.environ.setdefault("SL_CLOUD_PROVIDER", "aws")
    os.environ.setdefault("SL_CLOUD_REGION", "us-west-2")
    os.environ.setdefault("SL_CLOUD_ORGANIZATION_ID", "id-org-test")
    os.environ.setdefault("SL_FLINK_ENV_ID", "env-nknqp3")
    os.environ.setdefault("SL_CONFLUENT_PRINCIPAL_ID", "sa-test")
    os.environ.setdefault("SL_FLINK_COMPUTE_POOL_ID", "lfcp-xvrvmz")
    os.environ.setdefault("SL_FLINK_ENV_NAME", "j9r-env")
    os.environ.setdefault("SL_FLINK_DATABASE_NAME", "j9r-kafka")

from shift_left.core.utils.app_config import get_config
from shift_left.cli_commands.project import app
import shift_left.core.pipeline_mgr as pm
import subprocess

class TestProjectCLI(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        data_dir = pathlib.Path(__file__).parent / "../../data"  # Path to the data directory
        os.environ["PIPELINES"] = str(data_dir / "flink-project/pipelines")
        os.environ["SRC_FOLDER"] = str(data_dir / "dbt-project")
        os.environ["STAGING"] = str(data_dir / "flink-project/staging")
        pm.build_all_pipeline_definitions(os.getenv("PIPELINES",""))

    @classmethod
    def tearDownClass(cls):
        temp_dir = pathlib.Path(__file__).parent /  "../tmp"
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

    def test_init_project(self):
        runner = CliRunner()
        temp_dir = pathlib.Path(__file__).parent /  "../tmp"
        print(temp_dir)
        result = runner.invoke(app, [ "init", "project_test_via_cli", str(temp_dir)])
        print(result.stdout)
        assert result.exit_code == 0
        assert "Project project_test_via_cli created in " in result.stdout
        assert os.path.exists(temp_dir / "project_test_via_cli")
        assert os.path.exists(temp_dir / "project_test_via_cli/pipelines")



    @patch('shift_left.cli_commands.project.get_config')
    def test_validate_config_valid(self, mock_get_config):
        """Test validate_config with a valid configuration"""
        # Create a valid config for testing
        valid_config = {
            "kafka": {
                "bootstrap.servers": "test_bootstrap_servers:9092",
                "src_topic_prefix": "test_prefix",
                "cluster_id": "test_cluster",
                "pkafka_cluster": "test_pkafka",
                "cluster_type": "test_type"
            },
            "confluent_cloud": {
                "base_api": "https://api.confluent.cloud",
                "environment_id": "env-123",
                "cloud_region": "us-west-2",
                "cloud_provider": "aws",
                "organization_id": "org-123",
                "service_account_id": "sa-123",
                "api_key": "test_key",
                "api_secret": "test_secret",
                "url_scope": "test_scope"
            },
            "flink": {
                "flink_url": "https://flink.test.com",
                "api_key": "flink_key",
                "api_secret": "flink_secret",
                "compute_pool_id": "pool-123",
                "catalog_name": "test_catalog",
                "database_name": "test_db",
                "max_cfu": 10,
                "max_cfu_percent_before_allocation": 80
            },
            "app": {
                "delta_max_time_in_min": 60,
                "timezone": "UTC",
                "logging": "INFO",
                "data_limit_column_name_to_select_from": "created_at",
                "products": ["product1", "product2"],
                "accepted_common_products": ["common1"],
                "sql_content_modifier": "test_modifier",
                "dml_naming_convention_modifier": "test_dml_modifier",
                "compute_pool_naming_convention_modifier": "test_pool_modifier",
                "data_limit_where_condition": "WHERE 1=1",
                "data_limit_replace_from_reg_ex": "test_regex",
                "data_limit_table_type": "test_type"
            }
        }

        # Mock get_config to return our test configuration
        mock_get_config.return_value = valid_config

        runner = CliRunner()
        result = runner.invoke(app, ["validate-config"])
        print(result.stdout)
        assert result.exit_code == 0
        assert "validated" in result.stdout
        config_file = os.environ.get("SL_CONFIG_FILE", "config.yaml")
        assert config_file in result.stdout
        assert "Configuration validation failed" not in result.stdout

    @patch('shift_left.cli_commands.project.get_config')
    def test_validate_config_missing_sections(self, mock_get_config):
        """Test validate_config with missing required sections"""
        # Create config missing required sections
        invalid_config = {
            "kafka": {
                "src_topic_prefix": "test_prefix"
            }
            # Missing confluent_cloud, flink, app sections
        }

        # Mock get_config to return our test configuration
        mock_get_config.return_value = invalid_config

        runner = CliRunner()
        result = runner.invoke(app, ["validate-config"])
        print(result.stdout)
        # Should still exit with 0 but show validation errors in output
        assert "Configuration validation failed" in result.stdout
        assert "missing confluent_cloud section" in result.stdout
        assert "missing flink section" in result.stdout
        assert "missing app section" in result.stdout

    @patch('shift_left.cli_commands.project.get_config')
    def test_validate_config_placeholder_values(self, mock_get_config):
        """Test validate_config with placeholder values that need to be replaced"""
        # Create config with placeholder values
        config_with_placeholders = {
            "kafka": {
                 "bootstrap.servers": "test_bootstrap_servers:9092",
                "src_topic_prefix": "<TO_FILL>",
                "cluster_id": "test_cluster",
                "pkafka_cluster": "test_pkafka",
                "cluster_type": "test_type"
            },
            "confluent_cloud": {
                "base_api": "https://api.confluent.cloud",
                "environment_id": "env-123",
                "region": "us-west-2",
                "provider": "aws",
                "organization_id": "org-123",
                "api_key": "<kafka-api-key>",
                "api_secret": "<kafka-api-key_secret>",
                "url_scope": "test_scope"
            },
            "flink": {
                "flink_url": "https://flink.test.com",
                "api_key": "flink_key",
                "api_secret": "flink_secret",
                "compute_pool_id": "pool-123",
                "catalog_name": "test_catalog",
                "database_name": "test_db",
                "max_cfu": 10,
                "max_cfu_percent_before_allocation": 80
            },
            "app": {
                "delta_max_time_in_min": 60,
                "timezone": "UTC",
                "logging": "INFO",
                "data_limit_column_name_to_select_from": "created_at",
                "products": ["product1"],
                "accepted_common_products": ["common1"],
                "sql_content_modifier": "test_modifier",
                "dml_naming_convention_modifier": "test_dml_modifier",
                "compute_pool_naming_convention_modifier": "test_pool_modifier",
                "data_limit_where_condition": "WHERE 1=1",
                "data_limit_replace_from_reg_ex": "test_regex",
                "data_limit_table_type": "test_type"
            }
        }

        # Mock get_config to return our test configuration
        mock_get_config.return_value = config_with_placeholders

        runner = CliRunner()
        result = runner.invoke(app, ["validate-config"])
        print(result.stdout)
        assert "Configuration validation failed" in result.stdout
        assert "placeholder value '<TO_FILL>'" in result.stdout


    @patch('shift_left.cli_commands.project.get_config')
    def test_validate_config_invalid_data_types(self, mock_get_config):
        """Test validate_config with invalid data types"""
        # Create config with invalid data types
        invalid_types_config = {
            "kafka": {
                "src_topic_prefix": "test_prefix",
                "cluster_id": "test_cluster",
                "pkafka_cluster": "test_pkafka",
                "cluster_type": "test_type"
            },
            "confluent_cloud": {
                "base_api": "https://api.confluent.cloud",
                "environment_id": "env-123",
                "region": "us-west-2",
                "provider": "aws",
                "organization_id": "org-123",
                "api_key": "test_key",
                "api_secret": "test_secret",
                "url_scope": "test_scope"
            },
            "flink": {
                "flink_url": "https://flink.test.com",
                "api_key": "flink_key",
                "api_secret": "flink_secret",
                "compute_pool_id": "pool-123",
                "catalog_name": "test_catalog",
                "database_name": "test_db",
                "max_cfu": "not_a_number",  # Should be numeric
                "max_cfu_percent_before_allocation": 80
            },
            "app": {
                "delta_max_time_in_min": "not_a_number",  # Should be numeric
                "timezone": "UTC",
                "logging": "INVALID_LEVEL",  # Should be valid log level
                "data_limit_column_name_to_select_from": "created_at",
                "products": "not_a_list",  # Should be a list
                "accepted_common_products": "not_a_list",  # Should be a list
                "sql_content_modifier": "test_modifier",
                "dml_naming_convention_modifier": "test_dml_modifier",
                "compute_pool_naming_convention_modifier": "test_pool_modifier",
                "data_limit_where_condition": "WHERE 1=1",
                "data_limit_replace_from_reg_ex": "test_regex",
                "data_limit_table_type": "test_type"
            }
        }

        # Mock get_config to return our test configuration
        mock_get_config.return_value = invalid_types_config

        runner = CliRunner()
        result = runner.invoke(app, ["validate-config"])
        print(result.stdout)
        assert "Configuration validation failed" in result.stdout
        assert "must be a number" in result.stdout
        assert "must be a valid log level" in result.stdout
        assert "must be a list" in result.stdout

    @patch('shift_left.cli_commands.project.project_manager._assess_flink_statement_state')
    @patch('shift_left.core.project_manager.subprocess.run')
    def test_list_modified_files_success(self, mock_subprocess_run, mock_assess_state):
        """Test list_modified_files command with mocked git and temp project (no real git)."""
        runner = CliRunner()

        # Temp project dir with minimal SQL files so project_manager can open them
        with tempfile.TemporaryDirectory() as project_tmp:
            pipelines = pathlib.Path(project_tmp) / "pipelines"
            (pipelines / "sources/c360/src_users/sql-scripts").mkdir(parents=True)
            (pipelines / "facts/c360/fct_user_per_group/sql-scripts").mkdir(parents=True)
            (pipelines / "sources/c360/src_users/sql-scripts").joinpath("dml.src_c360_users.sql").write_text(
                "INSERT INTO src_c360_users SELECT 1"
            )
            (pipelines / "facts/c360/fct_user_per_group/sql-scripts").joinpath(
                "ddl.c360_fct_user_per_group.sql"
            ).write_text("CREATE TABLE c360_fct_user_per_group (id INT)")

            # Temp output dir so we don't touch real HOME
            with tempfile.TemporaryDirectory() as output_tmp:
                out_shift_left = pathlib.Path(output_tmp) / ".shift_left"
                out_shift_left.mkdir()
                old_home = os.environ.get("HOME")
                try:
                    os.environ["HOME"] = output_tmp
                    _modified_log = get_config().get("app", {}).get(
                        "modified_flink_files_file_name", "modified_flink_files.txt"
                    )
                    output_txt = out_shift_left / _modified_log

                    # Mock git (no real git calls)
                    mock_subprocess_run.side_effect = [
                        MagicMock(stdout="feature-branch\n", stderr="", returncode=0),
                        MagicMock(stdout="main\n", stderr="", returncode=0),
                        MagicMock(
                            stdout=(
                                "pipelines/sources/c360/src_users/sql-scripts/dml.src_c360_users.sql\n"
                                "pipelines/facts/c360/fct_user_per_group/sql-scripts/ddl.c360_fct_user_per_group.sql\n"
                                "src/some_file.py\ndocs/readme.md\n"
                            ),
                            stderr="",
                            returncode=0,
                        ),
                    ]
                    # Only DML file calls _assess_flink_statement_state
                    mock_assess_state.side_effect = [(False, True)]

                    result = runner.invoke(
                        app,
                        [
                            "list-modified-files",
                            "main",
                            "--file-filter", ".sql",
                            "--project-path", project_tmp,
                        ],
                    )

                    assert result.exit_code == 0
                    assert "Found 4 total modified files" in result.stdout
                    assert "Found 2 modified files matching filter '.sql'" in result.stdout

                    assert output_txt.exists()
                    content = output_txt.read_text()
                    # CLI writes table names (one per line) to the .txt file
                    assert "src_c360_users" in content
                    assert "c360_fct_user_per_group" in content
                finally:
                    if old_home is not None:
                        os.environ["HOME"] = old_home
                    else:
                        os.environ.pop("HOME", None)

    @patch('shift_left.core.project_manager.subprocess.run')
    def test_list_modified_files_no_matches(self, mock_subprocess_run):
        """Test list_modified_files when no files match the filter (mocked git, no real git)."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as output_tmp:
            out_shift_left = pathlib.Path(output_tmp) / ".shift_left"
            out_shift_left.mkdir()
            old_home = os.environ.get("HOME")
            try:
                os.environ["HOME"] = output_tmp
                _modified_log = get_config().get("app", {}).get(
                    "modified_flink_files_file_name", "modified_flink_files.txt"
                )
                output_txt = out_shift_left / _modified_log

                # Mock git log output: no .sql under pipelines
                mock_subprocess_run.side_effect = [
                    MagicMock(stdout="feature-branch\n", stderr="", returncode=0),
                    MagicMock(stdout="main\n", stderr="", returncode=0),
                    MagicMock(
                        stdout="src/some_file.py\ndocs/readme.md\nconfig.yaml\n",
                        stderr="",
                        returncode=0,
                    ),
                ]

                result = runner.invoke(app, [
                    "list-modified-files",
                    "main",
                    "--file-filter", ".sql",
                ])

                assert result.exit_code == 0
                assert "Total modified files: 0" in result.stdout
                assert "Found 3 total modified files" in result.stdout
                assert "Found 0 modified files matching filter '.sql'" in result.stdout
                assert output_txt.exists()
                assert output_txt.read_text() == ""
            finally:
                if old_home is not None:
                    os.environ["HOME"] = old_home
                else:
                    os.environ.pop("HOME", None)

    @patch('shift_left.core.project_manager.subprocess.run')
    def test_list_modified_files_git_error(self, mock_subprocess_run):
        """Test list_modified_files when git fails (mocked, no real git)."""
        runner = CliRunner()
        mock_subprocess_run.side_effect = subprocess.CalledProcessError(
            128, "git rev-parse", stderr="fatal: not a git repository"
        )

        result = runner.invoke(app, ["list-modified-files", "main"])

        assert result.exit_code == 1
        assert "Git command failed" in result.stdout

    @patch("shift_left.cli_commands.project.project_manager.impacted_tables_by_modifications")
    def test_list_impacted_tables_writes_json(self, mock_impacted):
        """Test list_impacted_tables writes impacted_tables.json under shift_left_dir."""
        from shift_left.core.project_manager import ImpactedTablesByModificationsResult

        runner = CliRunner()
        mock_impacted.return_value = ImpactedTablesByModificationsResult(
            ddl_modified_tables=["sl_raw_groups"],
            tables=["sl_c360_src_groups"],
            production_ddl_paths=["/tmp/ddl.src_c360_groups.sql"],
            unit_test_ddl_paths=["/tmp/tests/ddl_src_c360_groups.sql"],
        )

        with tempfile.TemporaryDirectory() as tmp:
            modified_json = pathlib.Path(tmp) / "modified_flink_files.json"
            modified_json.write_text(
                json.dumps(
                    {
                        "description": "test",
                        "file_list": [
                            {
                                "table_name": "sl_raw_groups",
                                "file_modified_url": "/pipelines/seeds/ddl.raw_groups.sql",
                                "same_sql_content": False,
                                "running": False,
                                "new_table_name": "sl_raw_groups",
                            }
                        ],
                    }
                )
            )
            out_shift_left = pathlib.Path(tmp) / ".shift_left"
            out_shift_left.mkdir()
            output_json = out_shift_left / "impacted_tables.json"

            with patch(
                "shift_left.cli_commands.project.shift_left_dir", str(out_shift_left)
            ):
                result = runner.invoke(
                    app,
                    [
                        "list-impacted-tables",
                        "--modified-files-path",
                        str(modified_json),
                        "--project-path",
                        str(pathlib.Path(tmp) / "pipelines"),
                        "--output-file",
                        str(output_json),
                    ],
                )

            assert result.exit_code == 0, result.stdout
            assert output_json.exists()
            payload = json.loads(output_json.read_text())
            assert payload["tables"] == ["sl_c360_src_groups"]
            assert "Impacted tables saved to" in result.stdout
            mock_impacted.assert_called_once()

    @patch("shift_left.cli_commands.project.compute_pool_mgr.delete_all_compute_pools_of_product")
    def test_delete_all_compute_pools_without_list_file(self, mock_delete_all):
        runner = CliRunner()
        result = runner.invoke(app, ["delete-all-compute-pools", "mv"])
        assert result.exit_code == 0, result.stdout
        mock_delete_all.assert_called_once_with("mv")

    @patch("shift_left.cli_commands.project.compute_pool_mgr.delete_compute_pools_by_ids")
    def test_delete_all_compute_pools_with_list_file_only(self, mock_delete_by_ids):
        runner = CliRunner()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("lfcp-ab0\n# comment\nlfcp-ab1\n")
            list_file = f.name
        try:
            result = runner.invoke(
                app,
                ["delete-all-compute-pools", "--compute-pool-list-file", list_file],
            )
            assert result.exit_code == 0, result.stdout
            mock_delete_by_ids.assert_called_once_with(["lfcp-ab0", "lfcp-ab1"], product_name=None)
        finally:
            os.unlink(list_file)

    @patch("shift_left.cli_commands.project.compute_pool_mgr.delete_compute_pools_by_ids")
    def test_delete_all_compute_pools_with_list_file_and_product(self, mock_delete_by_ids):
        runner = CliRunner()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("lfcp-ab0\n")
            list_file = f.name
        try:
            result = runner.invoke(
                app,
                ["delete-all-compute-pools", "mv", "--compute-pool-list-file", list_file],
            )
            assert result.exit_code == 0, result.stdout
            mock_delete_by_ids.assert_called_once_with(["lfcp-ab0"], product_name="mv")
        finally:
            os.unlink(list_file)

    def test_delete_all_compute_pools_requires_product_or_list_file(self):
        runner = CliRunner()
        result = runner.invoke(app, ["delete-all-compute-pools"])
        assert result.exit_code != 0
        assert "provide PRODUCT_NAME and/or --compute-pool-list-file" in result.stdout

    def test_delete_all_compute_pools_missing_list_file(self):
        runner = CliRunner()
        result = runner.invoke(
            app,
            ["delete-all-compute-pools", "--compute-pool-list-file", "/nonexistent/pools.txt"],
        )
        assert result.exit_code != 0


if __name__ == '__main__':
    unittest.main()
