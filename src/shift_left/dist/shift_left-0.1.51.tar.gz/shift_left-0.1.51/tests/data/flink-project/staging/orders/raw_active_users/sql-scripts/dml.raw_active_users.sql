INSERT INTO raw_active_users
SELECT 
-- part to select stuff
FROM src_table
WHERE -- where condition or remove it