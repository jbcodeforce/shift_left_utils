CREATE TABLE IF NOT EXISTS `orders` (
    `id` STRING,
    `product` STRING,
    `quantity` INT,
    `price` DECIMAL(10, 2),
    `timestamp` TIMESTAMP(3),
    PRIMARY KEY (`id`) NOT ENFORCED
) DISTRIBUTED BY HASH(`id`) INTO 1 BUCKETS WITH (
    'changelog.mode' = 'append',
    'kafka.retention.time' = '0',
    'kafka.producer.compression.type' = 'snappy',
    'scan.bounded.mode' = 'unbounded',
    'scan.startup.mode' = 'earliest-offset',
    'value.fields-include' = 'all',
    'key.json-registry.schema-context' = '.flink-dev',
    'value.json-registry.schema-context' = '.flink-dev',
    'key.format' = 'json-registry',
    'value.format' = 'json-registry'
);