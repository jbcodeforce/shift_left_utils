CREATE STREAM "filtered-orders" WITH (KAFKA_TOPIC='app.dev.filtered-orders', VALUE_FORMAT='JSON_SR')
AS SELECT * FROM "orders"
WHERE order_sum > 100
EMIT CHANGES;