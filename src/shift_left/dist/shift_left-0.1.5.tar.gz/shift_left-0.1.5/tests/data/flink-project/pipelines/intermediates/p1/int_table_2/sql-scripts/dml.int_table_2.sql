INSERT INTO int_table_2
SELECT 
*
FROM src_table_2;