insert into sl_c360_dim_groups_ut
(`group_id`, `tenant_id`, `group_name`, `group_type`, `tenant_name`, `created_date`, `is_active`, `updated_at`, `audit_source`)
values
(group_id_1, tenant_id_1, group_name_1, group_type_1, tenant_name_1, created_date_1, false, TIMESTAMP 2021-01-01 00:00:00, 'audit_source_1'),
(group_id_2, tenant_id_2, group_name_2, group_type_2, tenant_name_2, created_date_2, true, TIMESTAMP 2021-01-01 00:00:00, 'audit_source_2'),
(group_id_3, tenant_id_3, group_name_3, group_type_3, tenant_name_3, created_date_3, false, TIMESTAMP 2021-01-01 00:00:00, 'audit_source_3');