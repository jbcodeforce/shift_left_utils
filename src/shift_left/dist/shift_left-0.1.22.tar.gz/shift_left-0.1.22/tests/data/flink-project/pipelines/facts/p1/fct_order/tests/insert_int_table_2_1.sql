insert into int_table_2_ut
values ('order_1', 'product_1', 'user_id_1',10),
 ('order_2', 'product_1', 'user_id_2',15);