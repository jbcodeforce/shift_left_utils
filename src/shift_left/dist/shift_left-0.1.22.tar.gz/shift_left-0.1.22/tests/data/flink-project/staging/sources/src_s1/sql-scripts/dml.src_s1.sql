
INSERT INTO src_s1
SELECT
    
    -- change key and add columns
FROM ``;